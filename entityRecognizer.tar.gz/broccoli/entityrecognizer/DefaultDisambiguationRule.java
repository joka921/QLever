// Copyright 2014 Philipp Bausch, Manuel Ruder
// <{bauschp, rudera}@informatik.uni-freiburg.de>
package broccoli.entityrecognizer;

import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.disambiguation.Context;

/**
 * This interface is used to disambiguate entities. When overlapping it will
 * pick the longest. When identical names are found it will pick the one with
 * the highest score.
 */
public class DefaultDisambiguationRule implements
              EntityDisambiguationDecisionMaker {
  /**
   * Disambiguates two overlapping (@Link EntityAnnotation)'s.
   * Should be called when overlap is recognized.
   */
  public EntityAnnotation disambiguateOverlap(EntityAnnotation first,
    EntityAnnotation second) {
    // Take the one that is longer (more chars).
    if (first.isContainedIn(second)) {
      return disambiguateContainedIn(first, second);
    }
    int firstLength = first.getEnd() - first.getBegin();
    int secondLength = first.getEnd() - second.getBegin();
    return firstLength < secondLength ? second : first;
  }

  /**
   * Disambiguates an Annotation that is contained in a second Annotation.
   * <i>first</i> is contained in <i>second</i>.
   */
  public EntityAnnotation disambiguateContainedIn(EntityAnnotation first,
    EntityAnnotation second) {
    return second;
  }

  /**
   * Disambiguates two Entities which "collide" because they have the same name.
   */
  public SimpleBroccoliEntity disambiguateHomonym(SimpleBroccoliEntity first,
    SimpleBroccoliEntity second) {
    // Take the one with the highest score.
    return first.getScore() > second.getScore() ? first : second;
  }

  /**
   * Epsilon ge 0.
   */
  private static final float EPSILON = 5f;
  /**
   * The threshold factor for disambiguation.
   */
  private static final int THRESHOLDFACTOR = 100;

  /**
   * Disambiguates two Entities which "collide" because they have the same name
   * using context information.
   */
  public SimpleBroccoliEntity disambiguateHomonym(SimpleBroccoliEntity first,
      SimpleBroccoliEntity second, Context semanticContext) {
    // If the ratio of the popularity scores is larger than
    // a specific threshold, take always the popular entity.
    // APPROXIMATION for speed up. (The EPSILON trick would be enough,
    // but there you also need to calculate the similarity which is expensive)
    if (second.getScore() == 0
        || ((float) first.getScore() / (float) second.getScore())
            > THRESHOLDFACTOR) {
      return first;
    }
    if (first.getScore() == 0
        || ((float) second.getScore() / (float) first.getScore())
            > THRESHOLDFACTOR) {
      return second;
    }
    float firstSimilarity = first.getContext().similarityTo(semanticContext);
    float secondSimilarity = second.getContext().similarityTo(semanticContext);
    float firstScore = (float) first.getScore()
        * (EPSILON + firstSimilarity);
    float secondScore = (float) second.getScore()
        * (EPSILON + secondSimilarity);
    return firstScore > secondScore ? first : second;
  }
}
