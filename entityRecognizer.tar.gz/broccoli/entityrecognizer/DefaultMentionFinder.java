package broccoli.entityrecognizer;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

import broccoli.entityrecognizer.annotations.PossibleEntityAnnotation;
import broccoli.entityrecognizer.annotations.PossibleEntityEntitiesAnnotation;
import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.data.AdvancedEntityRepository;
import broccoli.entityrecognizer.GeneralERStateTracker.PronounKind;
import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.Sentence;

/**
 * A static class to find entities.
 * 
 * @author bauschp, Manuel Ruder
 * 
 */
public class DefaultMentionFinder extends MentionFinder {

  /**
   * The maximum amount of Tokens to be checked if entity.
   */
  private static final int MAXTOKENS = 14;
  /**
   * Maximum number of common noun tokens in a sequence when checking entity.
   */
  private static final int MAXTOKENS_COMMONNOUNS = 5;
  /**
   * The maximum surface length when checking for entity.
   */
  private static final int MAXSURFACELENGTH = 1000;

  /**
   * Whether to recognize pronouns. (he, she, it, ...)
   */
  private boolean recognizePronouns;

  /**
   * Whether to recognize class type co-refs. (the actor, ...)
   */
  private boolean recognizeClassTypeCoRefs;

  /**
   * Surface forms that are known to not be an entity.
   */
  private Set<String> nilReferences = new HashSet<String>();

  /**
   * A local cache for the surface form to entity map.
   * (to avoid unnecessary lookups)
   */
  private Map<String, List<SimpleBroccoliEntity> > knownEntities =
      new HashMap<String, List<SimpleBroccoliEntity> >();

  /**
   * Constructor.
   */
  public DefaultMentionFinder(boolean recognizePronouns,
      boolean recognizeClassTypeCoRefs) {
    super();
    this.recognizePronouns = recognizePronouns;
    this.recognizeClassTypeCoRefs = recognizeClassTypeCoRefs;
  }

  /**
   * Use the maximal sequence of NNs and only recognize the whole sequence.
   * This should give a higher precision in exchange for lower recall.
   * 
   * @param sentence
   * @param entityRepository
   * @return
   */
  public List<PossibleEntityAnnotation> getEntitiesForSentence(
      Sentence sentence, AdvancedEntityRepository entityRepository) {
    LinkedList<PossibleEntityAnnotation> result =
        new LinkedList<PossibleEntityAnnotation>();
    // Iterate over sentence tokens, in reverse order. If an entity was found,
    // jump to the token right before that entity to avoid overlapping.
    int i = sentence.getTokens().size() - 1;
    Token[] tokens = new Token[i + 1];
    for (int j = 0; j <= i; ++j) {
      tokens[j] = (Token) sentence.getTokens().get(j);
    }
    while (i >= 0) {
      i = recognizeNextEntityBackwards(
          entityRepository, tokens, i, sentence, result);
    }
    return result;
  }

  /**
   * Recognizes the next entity before the given index i, and returns a new
   * index right before that entity (or i - 1 if no entity was found).
   */
  private int recognizeNextEntityBackwards(
      AdvancedEntityRepository entityRepository, Token[] tokens, int i,
      Sentence sentence, LinkedList<PossibleEntityAnnotation> result) {
    // Check if this is a valid token (= noun) for direct detection.
    if (!isValidToken(tokens[i])) {
      // If not a noun, it could be a PRONOUN
      if (recognizePronouns) {
        PronounKind pronounKind =
            pronounMap.get(tokens[i].getCoveredText().toLowerCase());
        if (pronounKind != null) {
          result.addFirst(createPronounAnnotation(tokens[i], pronounKind));
        }
      }
      return i - 1;
    }
    // Check if possible CLASS TYPE COREFERENCE
    if (i > 0 && !isProperNoun(tokens[i]) && tokens[i - 1].getCoveredText()
        .equalsIgnoreCase(DEFINITE_ARTICLE)) {
      if (recognizeClassTypeCoRefs) {
        result.addFirst(createClassTypeAnnotation(tokens[i - 1], tokens[i]));
      }
      return i - 2;
    }
    int startToken = -1;  // Where the annotation starts
    int lastProperNounToken = 0;
    // Whether this sequence of tokens from i - index to i contains
    // a proper noun token
    boolean[] containsProperNoun =
        new boolean[Math.min(MAXTOKENS, i + 1)];
    containsProperNoun[0] = isProperNoun(tokens[i]); 
    for (int j = 1; j < containsProperNoun.length; ++j) {
      containsProperNoun[j] =
          containsProperNoun[j - 1] || isProperNoun(tokens[i - j]);
      if (isProperNoun(tokens[i - j])) {
        lastProperNounToken = j;
      }
      if (j - lastProperNounToken > MAXTOKENS_COMMONNOUNS) {
        break;
      }
    }
    List<SimpleBroccoliEntity> possibleMatches = null;
    List<SimpleBroccoliEntity> possibleContextualMatches = null;
    // Choose the entities which covers the most number of tokens.
    // (start with longest check)
    for (int j = Math.min(lastProperNounToken + MAXTOKENS_COMMONNOUNS,
                          containsProperNoun.length) - 1;
        j >= 0; --j) {
      int checkBegin = tokens[i - j].getBegin() - sentence.getBegin();
      int checkEnd = tokens[i].getEnd() - sentence.getBegin();
      if (checkEnd - checkBegin > MAXSURFACELENGTH) {
        continue;
      }
      String check =
          sentence.getCoveredText().substring(checkBegin, checkEnd);
      // Check if we saw this string before.
      if (knownEntities.containsKey(check)) {
        possibleMatches = knownEntities.get(check);
      } else {
        if (nilReferences.contains(check)) {
          break;
        }
        // If a proper noun, skip if it is surrounded by other proper nouns
        // and also skip further references to this token (nilReferences)
        if (j == 0 && containsProperNoun[0]
            && ((i - j > 0 && isProperNoun(tokens[i - j - 1]))
                || (i < tokens.length - 1 && isProperNoun(tokens[i + 1])))) {
          nilReferences.add(check);
          break;
        }
        possibleMatches =
            entityRepository.getBroccoliEntitiesByAlias(check);
      }
      // Check for possible contextual matches
      if (j == 0 && containsProperNoun[0]) {
        possibleContextualMatches =
            entityRepository.getBroccoliEntitiesByContextualAlias(check);
      }
      if (possibleMatches != null && !possibleMatches.isEmpty()) {
        startToken = i - j;
        knownEntities.put(check, possibleMatches);
        break;
      }
    }
    if (possibleMatches != null && !possibleMatches.isEmpty()) {
      // REGULAR ENTITY
      PossibleEntityEntitiesAnnotation annotation =
          new PossibleEntityEntitiesAnnotation(tokens[startToken].getBegin(),
              tokens[i].getEnd());
      annotation.entities = possibleMatches;
      annotation.possibleContextualMatches = possibleContextualMatches;
      annotation.tokens = new ArrayList<Token>(i - startToken + 1);
      annotation.isCommonNoun = !containsProperNoun[i - startToken];
      for (int j = startToken; j <= i; ++j) {
        annotation.tokens.add(tokens[j]);
      }
      result.addFirst(annotation);
      return startToken - 1;
    } else if (containsProperNoun[0]) {
      // If not an entity, it could be POSSIBLE COREF to a previous entity.
      PossibleEntityEntitiesAnnotation annotation =
          new PossibleEntityEntitiesAnnotation(tokens[i].getBegin(),
          tokens[i].getEnd());
      // Empty list to indicate that it can only be coRf (or contextual match)
      annotation.entities = new ArrayList<SimpleBroccoliEntity>(0);
      annotation.possibleContextualMatches = possibleContextualMatches;
      annotation.tokens = new ArrayList<Token>(1);
      annotation.tokens.add(tokens[i]);
      result.addFirst(annotation);
    }
    return i - 1;
  }

  /**
   * Returns true if this token is a proper noun.
   */
  private static boolean isProperNoun(Token token) {
    if (token.getCoveredText().isEmpty()) {
      return false;
    }
    // Special case for months or week names.
    if (unitOfTime.contains(token.getCoveredText())) {
      return false;
    }
    // Fallback if no pos tag.
    if (token.getPosTag() == null) {
      return Character.isUpperCase(token.getCoveredText().charAt(0));
    }
    return token.getPosTag().contains("NP");
  }

}
