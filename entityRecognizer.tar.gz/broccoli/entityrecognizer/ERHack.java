package broccoli.entityrecognizer;

import java.util.ArrayList;
import java.util.List;

import org.apache.uima.cas.FSIterator;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;

import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.data.BroccoliEntity;
import broccoli.entityrecognizer.data.BroccoliEntityMap;
import broccoli.entityrecognizer.data.EntityRecognitionResult;
import broccoli.uima.typesystem.Document;
import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.wiki.Link;
import broccoli.uima.typesystem.wiki.Section;

/**
 * @author buchholb
 * 
 */
public class ERHack {

  /**
   * The broccoli entity map that defines which entities are supported by
   * Broccoli.
   */
  private BroccoliEntityMap broccoliEntityMap;

  /**
   * 
   */
  private EntityRecognizerState repos;

  /**
   * @param broccoliEntityMap
   */
  public ERHack(BroccoliEntityMap broccoliEntityMap) {
    this.broccoliEntityMap = broccoliEntityMap;

    this.repos = new EntityRecognizerState();
  }

  /**
   * @param jcas
   * @return
   */
  public EntityRecognitionResult recognizeEntities(JCas jCas) {
    EntityRecognitionResult result = new EntityRecognitionResult();
    repos.reset();
    // There should be only one element.
    FSIterator<Annotation> iter =
        jCas.getAnnotationIndex(Document.type).iterator();
    
    BroccoliEntity documentEntity = null;
    
    if (iter.isValid()) {
      Document doc = (Document) iter.get();
      documentEntity =
          this.broccoliEntityMap.getBroccoliEntityInfo(doc.getTitle());
    }

    List<EntityAnnotation> recognizedEntities =
        new ArrayList<EntityAnnotation>();

    // determine the broccoli entity of the document if possible

    if (documentEntity != null) {
      this.repos.addDocumentEntity(documentEntity);
      this.repos.addEntity(documentEntity);
      result.setDocumentEntityBroccoliString(documentEntity
          .getBroccoliEntityName());
    }
    /*
     * else { //
     * System.out.println("WARNING: Could not resolve entity for title: " // +
     * doc.getTitle()); }
     */

    // Iterate over all annotations.

    boolean lastWordWasThe = false;

    for (iter = jCas.getAnnotationIndex().iterator(); iter.hasNext(); iter
        .next()) {

      // Case: Section
      if (iter.get().getClass().equals(Section.class)) {
        Section section = (Section) iter.get();
        this.repos.newSection(section.getLevel());
      }

      // Case: Token
      if (iter.get().getClass().equals(Token.class)) {
        Token token = (Token) iter.get();
        // Avoid recognizing linked entities twice.
        if (recognizedEntities.size() > 0
            && recognizedEntities.get(recognizedEntities.size() - 1).getEnd() 
            >= token.getEnd()) {
          continue;
        }

        BroccoliEntity entity =
            this.repos.getEntityForToken(token.getCoveredText().toLowerCase(),
                lastWordWasThe);
        if (entity != null) {
          EntityAnnotation entityAnnotation =
              new EntityAnnotation(token.getBegin(), token.getEnd());
          entityAnnotation.setName(entity.getBroccoliEntityName());
          entityAnnotation.setScore(repos.getScore(entity));
          // add the annotation to the result list
          recognizedEntities.add(entityAnnotation);
          this.repos.addEntity(entity);
        }
        if (token.getCoveredText().toLowerCase().equals("the")) {
          lastWordWasThe = true;
        } else {
          lastWordWasThe = false;
        }
      }

      // Case: Link
      if (iter.get().getClass().equals(Link.class)) {
        Link link = (Link) iter.get();
        // if the entity exists in the ontology entity list, create a new
        // entity
        // annotation and add it to the list
        BroccoliEntity entityInfo =
            this.broccoliEntityMap.getBroccoliEntityInfo(link.getTarget());
        if (entityInfo != null) {
          EntityAnnotation entityAnnotation =
              new EntityAnnotation(link.getBegin(), link.getEnd());
          entityAnnotation.setName(entityInfo.getBroccoliEntityName());
          entityAnnotation.setScore(repos.getScore(entityInfo));
          // add the annotation to the result list
          this.repos.addEntity(entityInfo);
          recognizedEntities.add(entityAnnotation);
        }
      }

      // Case anything else: do nothing / ignore annotation.
    }

    result.setRecognizedEntities(recognizedEntities);
    return result;
  }
}
