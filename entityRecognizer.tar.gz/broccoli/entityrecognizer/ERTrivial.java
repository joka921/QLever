package broccoli.entityrecognizer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import broccoli.entityrecognizer.annotations.Annotation;
import broccoli.entityrecognizer.annotations.DocumentAnnotation;
import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.annotations.SectionAnnotation;
import broccoli.entityrecognizer.annotations.TokenAnnotation;
import broccoli.entityrecognizer.data.BroccoliEntity;
import broccoli.entityrecognizer.data.BroccoliEntityMap;
import broccoli.entityrecognizer.data.EntityRecognitionResult;
import broccoli.utility.ScoreCalculator;

/**
 * A trivial entity recognizer that can recognize the entities of the ontology
 * in a text.
 * 
 * @author Florian Bäurle
 */
public class ERTrivial {
  /**
   * The broccoli entity map that defines which entities are supported by
   * Broccoli.
   */
  private BroccoliEntityMap broccoliEntityMap;

  /**
   * A set of the allowed classes. If not <code>null</code>, only entities that
   * are from a class in this set are recognized.
   */
  private HashSet<String> allowedClasses;

  /**
   * Creates a new {@link ERTrivial}.
   * 
   * @param broccoliEntityMap
   *          The entity map that specifies the entities that are supported by
   *          Broccoli.
   * @param allowedClassesFile
   *          The path to the optional allowed classes file. Can be set to the
   *          empty string or <code>null</code> if the useAllowedClassesFile
   *          param is <code>false</code>.
   * @param useAllowedClassesFile
   *          Determines if the optional allowed classes file should be used (
   *          <code>true</code>) or not (<code>false</code>).
   */
  public ERTrivial(BroccoliEntityMap broccoliEntityMap,
      String allowedClassesFile, boolean useAllowedClassesFile) {
    this.broccoliEntityMap = broccoliEntityMap;

    // read the allowed classes from the classes file
    if (useAllowedClassesFile) {
      if (allowedClassesFile == null) {
        throw new IllegalArgumentException(
            "If the allowed classes file should be used, the "
                + "allowed-classes-file path must not be null!");
      }
      try {
        this.allowedClasses = new HashSet<String>();

        System.out
            .print("Restricting the entity recognition to the following "
                + "classes: ");

        File acFile = new File(allowedClassesFile);
        FileInputStream acStream = new FileInputStream(acFile);
        InputStreamReader acStreamReader =
            new InputStreamReader(acStream, "UTF-8");
        BufferedReader acReader = new BufferedReader(acStreamReader);
        String line;
        int lineCount = 0;
        while ((line = acReader.readLine()) != null) {

          if (!line.isEmpty()) {
            ++lineCount;
            this.allowedClasses.add(line);
            if (lineCount > 1) {
              System.out.print(", ");
            }
            System.out.print(line);
          }
        }

        System.out.println();

        acReader.close();
      } catch (FileNotFoundException e) {
        throw new RuntimeException(
            "The supplied Allowed-Classes-File could not be found: "
                + e.getMessage());
      } catch (UnsupportedEncodingException e) {
        throw new RuntimeException(
            "Error while reading the supplied Allowed-Classes-File: "
                + e.getMessage());
      } catch (IOException e) {
        throw new RuntimeException(
            "Error while reading the supplied Allowed-Classes-File: "
                + e.getMessage());
      }
    }
  }

  /**
   * Performs an entity recognition for the given annotated document.
   * 
   * @param documentAnnotation
   *          The annotated document in which entities should be recognized.
   * @param sectionAnnotations
   *          A list of the section annotations for the document.
   * @param sentenceAnnotations
   *          A list of sentence annotations for the document.
   * @param tokenAnnotations
   *          A list of token annotations for the document.
   * @return A list containing the recognized entities as annotations.
   */
  public EntityRecognitionResult recognizeEntities(
    DocumentAnnotation documentAnnotation,
    List<SectionAnnotation> sectionAnnotations,
    List<Annotation> sentenceAnnotations,
    List<TokenAnnotation> tokenAnnotations) {

    EntityRecognitionResult result = new EntityRecognitionResult();

    List<EntityAnnotation> recognizedEntities =
        new ArrayList<EntityAnnotation>();

    // determine the broccoli entity of the document if possible
    BroccoliEntity documentEntityInfo =
        this.broccoliEntityMap.getBroccoliEntityInfo(documentAnnotation
            .getTitle());
    String documentEntityBroccoliString = null;
    if (documentEntityInfo != null) {
      documentEntityBroccoliString =
          documentEntityInfo.getBroccoliEntityName();
    } else {
      // if the document title was not found, try the document title up to
      // (excluding) the first colon
      String titleToColon = documentAnnotation.getTitle();
      int firstColonIndex = titleToColon.indexOf(':');
      if (firstColonIndex > 0) {
        titleToColon = titleToColon.substring(0, firstColonIndex);
        documentEntityInfo =
            this.broccoliEntityMap.getBroccoliEntityInfo(titleToColon);
        if (documentEntityInfo != null) {
          documentEntityBroccoliString =
              documentEntityInfo.getBroccoliEntityName();
        }
      }
    }
    // set the document entity to the result
    result.setDocumentEntityBroccoliString(documentEntityBroccoliString);
    // create a score calculator for the document
    ScoreCalculator scoreCalculator =
        new ScoreCalculator(documentEntityBroccoliString);

    // initialize some variables to be able to iterate through the documents
    // structure
    Iterator<Annotation> sentencesIt = sentenceAnnotations.iterator();
    Annotation nextSentence = null;
    if (sentencesIt.hasNext()) {
      nextSentence = sentencesIt.next();
    }
    Iterator<TokenAnnotation> tokensIt = tokenAnnotations.iterator();
    TokenAnnotation nextToken = null;
    if (tokensIt.hasNext()) {
      nextToken = tokensIt.next();
    }
    // go through the document section per section and recognize entities
    int currentSectionIndex = 0;
    for (SectionAnnotation currentSection : sectionAnnotations) {
      // loop through all sentences that are in the current section
      if (nextSentence != null) {
        int currentSentenceIndex = 0;
        boolean nextSentenceIsInSection =
            nextSentence.isContainedIn(currentSection);
        while (nextSentenceIsInSection) {
          Annotation currentSentence = nextSentence;

          // get all tokens that are in the current sentence
          List<TokenAnnotation> sentenceTokens =
              new ArrayList<TokenAnnotation>();
          if (nextToken != null) {
            boolean nextTokenIsInSentence =
                nextToken.isContainedIn(currentSentence);
            while (nextTokenIsInSentence) {
              TokenAnnotation currentToken = nextToken;

              sentenceTokens.add(currentToken);

              // get the next token
              if (!tokensIt.hasNext()) {
                nextToken = null;
                break;
              } else {
                nextToken = tokensIt.next();
                nextTokenIsInSentence =
                    nextToken.isContainedIn(currentSentence);
              }
            }
          }

          // loop through the tokens of the current sentence and recognize
          // known entities
          // therefore just use their literal strings and prefer composed
          // entities over atomic entities
          int startIndex = 0;
          while (startIndex < sentenceTokens.size()) {
            // int endIndex = sentenceTokens.size() - 1;
            // restrict composed entities to max 10 tokens to reduce time needed
            int endIndex =
                Math.min(startIndex + 10, sentenceTokens.size() - 1);
            while (endIndex >= startIndex) {
              // StringBuilder currentString = new StringBuilder();
              // for (int i=startIndex; i<= endIndex; ++i)
              // {
              // currentString.append(sentenceTokens.get(i).getCoveredText());
              // }
              int currentBegin = sentenceTokens.get(startIndex).getBegin();
              int currentEnd = sentenceTokens.get(endIndex).getEnd();
              String currentString =
                  documentAnnotation.getText().substring(currentBegin,
                      currentEnd);

              // check if the current string is a known entity by trying to get
              // its info
              BroccoliEntity entityInfo =
                  this.broccoliEntityMap.getBroccoliEntityInfo(currentString);

              boolean recognizeEntity = false;
              // if the entity info is not null the entity was found in the
              // ontology
              if (entityInfo != null) {
                // if the allowed classes are restricted test if the entity is
                // allowed to be recognized
                if (this.allowedClasses != null) {
                  for (String entityClass : entityInfo.getClasses()) {
                    if (this.allowedClasses.contains(entityClass)) {
                      recognizeEntity = true;
                      break;
                    }
                  }
                } else {
                  // else just recognize it
                  recognizeEntity = true;
                }
              }

              if (recognizeEntity) {
                // create a new entity annotation
                EntityAnnotation entityAnnotation =
                    new EntityAnnotation(currentBegin, currentEnd);
                // set the name
                entityAnnotation.setName(entityInfo.getBroccoliEntityName());
                // set the score
                entityAnnotation.setScore(scoreCalculator.calculateScore(
                    entityInfo, currentSectionIndex, currentSentenceIndex));
                // add the annotation to the result list
                recognizedEntities.add(entityAnnotation);

                // continue the search in the rest of the sentence
                startIndex = endIndex + 1;
                break;
              } else {
                --endIndex;
                if (endIndex < startIndex) {
                  ++startIndex;
                }
              }
            }
          }

          // get the next sentence
          if (!sentencesIt.hasNext()) {
            nextSentence = null;
            break;
          } else {
            nextSentence = sentencesIt.next();
            nextSentenceIsInSection =
                nextSentence.isContainedIn(currentSection);
            ++currentSentenceIndex;
          }
        }
      }
      ++currentSectionIndex;
    }

    // set the recognized entities to the result
    result.setRecognizedEntities(recognizedEntities);

    return result;
  }
}
