// Copyright 2014 Philipp Bausch <bauschp@informatik.uni-freiburg.de>
package broccoli.entityrecognizer;

import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.disambiguation.Context;

/**
 * This interface is used to disambiguate entities.  The methodes describe
 * rules, invoked when a disambiguation has to be made.
 */
public interface EntityDisambiguationDecisionMaker {
  /**
   * Disambiguates two overlaping (@Link EntityAnnotation)'s.
   * Should be called when overlap is recognized.
   */
  EntityAnnotation disambiguateOverlap(EntityAnnotation first,
    EntityAnnotation second);

  /**
   * Disambiguates an Annotation that is contained in a second Annotation.
   * <i>first</i> is contained in <i>second</i>.
   */
  EntityAnnotation disambiguateContainedIn(EntityAnnotation first,
    EntityAnnotation second);

  /**
   * Disambiguates two Entities which "collide" because they have the same name.
   */
  SimpleBroccoliEntity disambiguateHomonym(SimpleBroccoliEntity first,
    SimpleBroccoliEntity second);
    
  /**
   * Disambiguates two Entities which "collide" because they have the same name
   * using context information.
   */
  SimpleBroccoliEntity disambiguateHomonym(SimpleBroccoliEntity first,
    SimpleBroccoliEntity second, Context semanticContext);
}
