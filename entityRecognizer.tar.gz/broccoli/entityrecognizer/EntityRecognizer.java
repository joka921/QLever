package broccoli.entityrecognizer;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import broccoli.entityrecognizer.EntityRecognizerState.ERResult;
import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.data.BroccoliEntity;
import broccoli.entityrecognizer.data.EntityRecognitionResult;
import broccoli.entityrecognizer.data.EntityRepository;
import broccoli.entityrecognizer.data.EntitySurfaceMap;
import broccoli.uima.typesystem.Document;
import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.wiki.Link;
import broccoli.uima.typesystem.wiki.Section;

import org.apache.uima.cas.FSIterator;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;

/**
 * A generic entity recognizer that uses wikipedia links to recognize 
 * entities but also recognizes additional entities.
 *  
 */
public class EntityRecognizer {
  
  /**
   * The complete entity repository.
   */
  private EntityRepository entityRepository;
  
  /**
   * A map from text surface forms of entities to corresponding entity.
   */
  private static EntitySurfaceMap entitySurfaceMap;
  
  /**
   * A map from text surface string to corresponding entity
   * for entities in specific classes. 
   */
  private static EntitySurfaceMap surfaceLiteralEntityMap;


  /**
   * Track the state of the current recognition process.
   */
  private EntityRecognizerState recognizerState;
  
  /**
   * 
   */
  private Set<String> uppercaseClasses;
  
  
  /**
   * Creates a new {@link EntityRecognizer}.
   * 
   * @param entityRepository
   *          The entity map that specifies the entities that are supported by
   *          Broccoli.
   */
  public EntityRecognizer(EntityRepository entityRepository, 
    Set<String> uppercaseClasses) {
    this.entityRepository = entityRepository;
    this.uppercaseClasses = uppercaseClasses;
    
    initializeEntitySurfaceLiteralMap(this.entityRepository, 
        null);
    initializeEntitySurfaceMap(this.entityRepository);
    this.recognizerState = new EntityRecognizerState();
    this.recognizerState.setEntitySurfaceMap(surfaceLiteralEntityMap);
  }

  /**
   * 
   * @param er
   * @return
   */
  private static synchronized void initializeEntitySurfaceMap(
    EntityRepository er) {
    if (entitySurfaceMap == null) {
      entitySurfaceMap = new EntitySurfaceMap(er);
    }
  }

  /**
   * 
   * @param er
   * @param directClasses
   * @return
   */
  private static synchronized void initializeEntitySurfaceLiteralMap(
    EntityRepository er, Set<String> directClasses) {
    if (surfaceLiteralEntityMap == null) {
      surfaceLiteralEntityMap = new EntitySurfaceMap(er, directClasses, true);
    }
  }

  /**
   * Performs an entity recognition for the given annotated document.
   * 
   */
  public EntityRecognitionResult recognizeEntities(JCas jCas) {
    EntityRecognitionResult result = new EntityRecognitionResult();
    recognizerState.reset();
    // There should be only one element.
    FSIterator<Annotation> iter =
        jCas.getAnnotationIndex(Document.type).iterator();
    
    BroccoliEntity documentEntity = null;
    
    if (iter.isValid()) {
      Document doc = (Document) iter.get();
      // Only recognize in surfaceLiterlEntityMap that contains
      // unique names.
      documentEntity =
          this.recognizerState.recognizeDocumentEntity(
              doc.getTitle(), surfaceLiteralEntityMap);
    }

    List<EntityAnnotation> recognizedEntities =
        new ArrayList<EntityAnnotation>();

    // determine the broccoli entity of the document if possible
    if (documentEntity != null) {
      result.setDocumentEntityBroccoliString(documentEntity
          .getBroccoliEntityName());
    }
    /*
     * else { //
     * System.out.println("WARNING: Could not resolve entity for title: " // +
     * doc.getTitle()); }
     */
    
    // NEW 04.03.14 (Florian): HACK: check if the document has any section
    //  annotations, if not then act as if the whole document just has one
    //  enclosing section
    if (jCas.getAnnotationIndex(Section.type).size() == 0) {
      this.recognizerState.newSection(1);
    }

    // Iterate over all annotations.

    boolean lastWordWasThe = false;

    for (iter = jCas.getAnnotationIndex().iterator(); iter.hasNext(); iter
        .next()) {

      // Case: Section
      if (iter.get().getClass().equals(Section.class)) {
        Section section = (Section) iter.get();
        this.recognizerState.newSection(section.getLevel());
      }

      // Case: Token
      if (iter.get().getClass().equals(Token.class)) {
        Token token = (Token) iter.get();
        // Avoid recognizing linked entities twice.
        if (recognizedEntities.size() > 0
            && recognizedEntities.get(recognizedEntities.size() - 1).getEnd() 
            >= token.getEnd()) {
          continue;
        }
        BroccoliEntity entity =
            this.recognizerState.getEntityForToken(
                token.getCoveredText().toLowerCase(),
                lastWordWasThe);
        // Check for successful result and whether the entity
        // is different from the previous one. This can happen
        // for short form of names that are unique (President Truman).
        if (entity != null) {
          EntityAnnotation entityAnnotation =
              new EntityAnnotation(token.getBegin(), token.getEnd());
          entityAnnotation.setName(entity.getBroccoliEntityName());
          entityAnnotation.setScore(recognizerState.getScore(entity));
          // add the annotation to the result list
          recognizedEntities.add(entityAnnotation);
          this.recognizerState.addEntity(entity);
        }
        ERResult erResult = this.recognizerState
            .getEntityForLastTokensHighPrecision(surfaceLiteralEntityMap,
                uppercaseClasses,
                token,
                this.entityRepository);
        if (erResult != null) {
          boolean addAnnotation = true;
          // Check if the same erResult
          if (recognizedEntities.size() > 0) {
            EntityAnnotation lastAnnot = recognizedEntities
                .get(recognizedEntities.size() - 1);
            if (erResult.tokens.get(0).getBegin() == lastAnnot.getBegin()
                && erResult.tokens.get(erResult.tokens.size() - 1).getEnd() 
                == lastAnnot.getEnd()) {
              addAnnotation = false;
            }
          }
          if (addAnnotation) {
            entity = erResult.entity;
            EntityAnnotation entityAnnotation = new EntityAnnotation(
                erResult.tokens.get(0).getBegin(), erResult.tokens.get(
                    erResult.tokens.size() - 1).getEnd());
            // Remove all annotations the are contained in this recognized
            // entities.
            for (int i = recognizedEntities.size() - 1; i >= 0; --i) {
              if (recognizedEntities.get(i).isContainedIn(entityAnnotation)) {
                recognizedEntities.remove(i);
              } else {
                break;
              }
            }
            entityAnnotation.setName(entity.getBroccoliEntityName());
            entityAnnotation.setScore(recognizerState.getScore(entity));
            // add the annotation to the result list
            recognizedEntities.add(entityAnnotation);
            // This should also update the information that was added for
            // the possibly contained annotation that was removed above.
            this.recognizerState.addEntity(entity);
          }
        }
        if (token.getCoveredText().toLowerCase().equals("the")) {
          lastWordWasThe = true;
        } else {
          lastWordWasThe = false;
        }
      }

      // Case: Link
      if (iter.get().getClass().equals(Link.class)) {
        Link link = (Link) iter.get();
        // if the entity exists in the ontology entity list, create a new
        // entity
        // annotation and add it to the list
        String linkTarget = link.getTarget();
        if (linkTarget.length() > 0) {
          linkTarget = Character.toUpperCase(linkTarget.charAt(0))
              + linkTarget.substring(1);
        }
        BroccoliEntity entityInfo =
            entitySurfaceMap.getBroccoliEntity(linkTarget);
        if (entityInfo != null) {
          EntityAnnotation entityAnnotation =
              new EntityAnnotation(link.getBegin(), link.getEnd());
          entityAnnotation.setName(entityInfo.getBroccoliEntityName());
          entityAnnotation.setScore(recognizerState.getScore(entityInfo));
          // add the annotation to the result list
          this.recognizerState.addEntity(entityInfo);
          recognizedEntities.add(entityAnnotation);
        }
      }
      // Case anything else: do nothing / ignore annotation.
    }

    result.setRecognizedEntities(recognizedEntities);
    return result;
  }
}
