package broccoli.entityrecognizer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import broccoli.entityrecognizer.data.BroccoliEntity;
import broccoli.entityrecognizer.data.EntityRepository;
import broccoli.entityrecognizer.data.EntitySurfaceMap;
import broccoli.uima.typesystem.Token;

/**
 * Tracks the current state of the entity recognizer.
 * 
 * @author buchholb
 * 
 */
public class EntityRecognizerState {

  /**
   * A simple result container.
   * @author haussmae
   *
   */
  public class ERResult {
    /**
     * The recognized entities.
     */
    public BroccoliEntity entity;
    
    /**
     * The tokens on which the entity was recognized.
     */
    public ArrayList<Token> tokens = new ArrayList<Token>();
  }

  /**
   * Minimum entity score required for an entity that is
   * recognized directly (w/o a wiki-link).
   */
  private static final int MIN_ENTITY_SCORE = -1;
  
  
  /**
   * To differentiate pronouns.
   * @author haussmae
   *
   */
  enum PronounKind {
    /**
     * Female.
     */
    FEMALE,
    /**
     * Male.
     */
    MALE,
    /**
     * Other.
     */
    OTHER
  };

  /**
   * 
   */
  public EntityRecognizerState() {
    this.activeEntities = new ArrayList<HashMap<String, BroccoliEntity>>();
    this.pronounMap = new HashMap<String, PronounKind>();
    this.lastTokens = new ArrayList<Token>();
    // 1: male, 2: female, 3: no person
    this.pronounMap.put("he", PronounKind.MALE);
    this.pronounMap.put("his", PronounKind.MALE);
    this.pronounMap.put("him", PronounKind.MALE);
    this.pronounMap.put("himself", PronounKind.MALE);
    this.pronounMap.put("she", PronounKind.FEMALE);
    this.pronounMap.put("her", PronounKind.FEMALE);
    this.pronounMap.put("herself", PronounKind.FEMALE);
    this.pronounMap.put("it", PronounKind.OTHER);
    this.pronounMap.put("its", PronounKind.OTHER);
    this.pronounMap.put("itself", PronounKind.OTHER);
  }

  /**
   * 
   */
  private BroccoliEntity lastEntity;

  /**
   * 
   */
  private EntitySurfaceMap entitySurfaceMap;

  /**
   * 
   * @return
   */
  public EntitySurfaceMap getEntitySurfaceMap() {
    return entitySurfaceMap;
  }

  /**
   * 
   * @param entitySurfaceMap
   */
  public void setEntitySurfaceMap(EntitySurfaceMap entitySurfaceMap) {
    this.entitySurfaceMap = entitySurfaceMap;
  }

  /**
   * 
   */
  private BroccoliEntity documentEntity;

  /**
   * Map section -> entities.
   */
  private ArrayList<HashMap<String, BroccoliEntity>> activeEntities;

  /**
   * 
   */
  private Map<String, PronounKind> pronounMap;

  /**
   * The last tokens. Used to directly recognize entities in text.
   */
  private ArrayList<Token> lastTokens;

  /**
   * @param entityInfo
   */
  public void addEntity(BroccoliEntity entityInfo) {
    String uri = entityInfo.getBroccoliEntityName().substring(
        entityInfo.getBroccoliEntityName().lastIndexOf(':') + 1);
    StringTokenizer st = new StringTokenizer(uri, "_");
    while (st.hasMoreTokens()) {
      String tok = st.nextToken().toLowerCase();
      if (tok.length() > 3) {
        this.activeEntities.get(this.activeEntities.size() - 1).put(tok,
            entityInfo);
      }
    }
    lastEntity = entityInfo;
  }

  /**
   * @param level
   */
  public void newSection(int level) {
    if (activeEntities.size() <= level) {
      while (activeEntities.size() <= level) {
        activeEntities.add(new HashMap<String, BroccoliEntity>());
      }
    } else {
      if (level != 0) {
        activeEntities.subList(level, activeEntities.size()).clear();
        activeEntities.add(new HashMap<String, BroccoliEntity>());
      }
    }
    lastEntity = documentEntity;
  }

  /**
   * 
   */
  public void reset() {
    this.activeEntities.clear();
    this.lastTokens.clear();
    this.lastEntity = null;
    this.documentEntity = null;
  }

  /**
   * @param documentEntityBroccoliString
   */
  public void addDocumentEntity(BroccoliEntity entity) {
    this.documentEntity = entity;
    if (this.activeEntities.size() < 1) {
      this.activeEntities.add(new HashMap<String, BroccoliEntity>());
    }
    String title = entity.getBroccoliEntityName().substring(
        entity.getBroccoliEntityName().lastIndexOf(':') + 1);
    StringTokenizer st = new StringTokenizer(title, "_");
    while (st.hasMoreTokens()) {
      String tok = st.nextToken().toLowerCase();
      if (tok.length() > 3) {
        this.activeEntities.get(this.activeEntities.size() - 1)
            .put(tok, entity);
      }
    }
    lastEntity = entity;
  }

  /**
   * @param broccoliEntityString
   * @return
   */
  public int getScore(BroccoliEntity entity) {
    if (entity.getAbstractnessCount() >= 10) {
      return 0;
    } else {
      if (entity.equals(this.documentEntity)) {
        return (this.activeEntities.size() <= 1 ? 150 : 100);
      } else {
        return 1;
      }
    }
  }

  /**
   * Get the entity referenced by the given token or null if there is none.
   * TODO(buchholb): Stop recognizing "Albert Einstein" as two occurrences of
   * the same entity. However, this is the same thing that was also done in the
   * old chain.
   * 
   * @param token
   * @return
   */
  public BroccoliEntity getEntityForToken(String token,
    boolean lastWordWasThe) {
    // Check pronouns
    PronounKind pronounKind = isPronoun(token);
    if (pronounKind != null) {
      return (matchPronoun(pronounKind));
    }

    // Check classes
    if (lastWordWasThe) {
      BroccoliEntity retForClass = handleClassOccurrence(token);
      if (retForClass != null) {
        return retForClass;
      }
    }

    // Check min wordlength and map lookup
    // TODO(buchholb): externalize magic number or better replace
    // by usage of a stopwords list.
    if (token.length() > 2) {
      for (int i = this.activeEntities.size() - 1; i >= 0; --i) {
        BroccoliEntity res = this.activeEntities.get(i)
            .get(token.toLowerCase());
        if (res != null) {
          lastEntity = res;
          return res;
        }
      }
    }

    // No match.
    return null;
  }
  
  /**
   * Return true if the provided token is part of an NP.
   * @param token
   * @return
   */
  private boolean isPartOfNP(Token token) {
    if (token.getCoveredText().length() == 0) {
      return false;
    }
    if (token.getPosTag() == null) {
      return false;
    }
    // If the token is not a noun.
    if (!token.getPosTag().startsWith("N")) {
      return false;
    } else {
      String text = token.getCoveredText();
      // For length 1 strings only if it is a character or digit.
      if (text.length() == 1) {
        if (!Character.isLetterOrDigit(text.charAt(0))) {
          return false;
        } 
      }
      return true;
    }
  }
  
  /**
   * Use the maximal sequence of NNs and only recognize the whole sequence. This
   * should give a higher precision in exchange for lower recall.
   * 
   * @param surfaceLiteralMap
   * @param currentToken
   * @param entityRepository 
   * @return
   */
  public ERResult getEntityForLastTokensHighPrecision(
    EntitySurfaceMap surfaceLiteralMap,
    Set<String> uppercaseClasses,
    Token currentToken, EntityRepository entityRepository) {
    if (!isPartOfNP(currentToken)) {
      if (lastTokens.size() > 0) {
        ERResult result = null;
        if (lastTokens.size() != 1
            || entityRepository.getWordConcreteness(lastTokens.get(0)
                .getCoveredText().toLowerCase()) >= 0.20) {
          StringBuffer entityStringBuffer = new StringBuffer();
          for (int i = 0; i < lastTokens.size(); ++i) {
            entityStringBuffer.append(lastTokens.get(i).getCoveredText());
            if (i != lastTokens.size() - 1) {
              entityStringBuffer.append(" ");
            }
          }
          String entityString = entityStringBuffer.toString();
          BroccoliEntity entity = surfaceLiteralMap
              .getBroccoliEntity(entityString);
          // Try to find an uppercase entity.
          if (entity ==  null) {
            entity = surfaceLiteralMap
                .getBroccoliEntity(firstCharUpper(entityString));
          }
          // If the entity string does not start with an upper-case
          // character, only recognize it if it is not in one of
          // the selected upper-cases classes.
          if (entity != null && entityString.length() > 0
              && Character.isLowerCase(entityString.charAt(0))) {
            for (String uppercaseClass : uppercaseClasses) {
              if (entity.isInstanceOf(uppercaseClass)) {
                entity = null;
                break;
              }
            }
          }
          if (entity != null && entity.getScore() > MIN_ENTITY_SCORE) {
            result = new ERResult();
            result.entity = entity;
            result.tokens.addAll(lastTokens);
          }
        }
        lastTokens.clear();
        return result;
      }
    } else {
      lastTokens.add(currentToken);
    }
    return null;
  }

  /**
   * @param maybeAClass
   * @return the matching entity or null
   */
  private BroccoliEntity handleClassOccurrence(String maybeAClass) {
    BroccoliEntity res = null;
    if (maybeAClass != null) {
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf(maybeAClass)) {
        res = this.documentEntity;
      } else if (this.lastEntity != null
          && this.lastEntity.isInstanceOf(maybeAClass)) {
        res = this.lastEntity;
      }
    }
    return res;
  }

  /**
   * 
   * @param pronounKind
   * @return a matching entity or null
   */
  private BroccoliEntity matchPronoun(PronounKind pronounKind) {
    if (pronounKind == PronounKind.MALE) {
      // A male person
      if (this.lastEntity != null && this.lastEntity.isInstanceOf("person")
          && this.lastEntity.getGender() == BroccoliEntity.Gender.MALE) {
        return lastEntity;
      }
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf("person")
          && this.documentEntity.getGender() == BroccoliEntity.Gender.MALE) {
        return documentEntity;
      }
    } else if (pronounKind == PronounKind.FEMALE) {
      // A female person
      if (this.lastEntity != null && this.lastEntity.isInstanceOf("person")
          && this.lastEntity.getGender() == BroccoliEntity.Gender.FEMALE) {
        return lastEntity;
      }
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf("person")
          && this.documentEntity.getGender() == BroccoliEntity.Gender.FEMALE) {
        return documentEntity;
      }
    } else {
      // No person
      if (this.lastEntity != null && !this.lastEntity.isInstanceOf("person")) {
        return lastEntity;
      }
      if (this.documentEntity != null
          && !this.documentEntity.isInstanceOf("person")) {
        return documentEntity;
      }
    }
    return null;
  }
  
  /**
   * @param s The string to modify
   * @return Parameter s with the first character made uppercase.
   * @param s
   * @return
   */
  private String firstCharUpper(String s) {
    return Character.toUpperCase(s.charAt(0)) + s.substring(1);
  }

  /**
   * @param token
   * @return the kind of the pronoun or null if token isn't an
   *  anaphora pronoun at
   *         all.
   */
  private PronounKind isPronoun(String token) {
    PronounKind num = this.pronounMap.get(token);
    return num;
  }

  /**
   * Recognize the document entity and update state.
   * 
   * @param title
   * @param surfaceMap
   * @return
   */
  public BroccoliEntity recognizeDocumentEntity(String title,
    EntitySurfaceMap surfaceMap) {
    BroccoliEntity result = surfaceMap.getBroccoliEntity(title);
    if (result != null) {
      this.addDocumentEntity(result);
      this.addEntity(result);
    }
    return result;
  }

}
