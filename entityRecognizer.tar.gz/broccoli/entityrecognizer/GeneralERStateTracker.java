package broccoli.entityrecognizer;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.StringTokenizer;

import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.data.AdvancedEntityRepository;
import broccoli.entityrecognizer.annotations.PossibleEntityAnnotation;
import broccoli.entityrecognizer.annotations.PossibleEntityEntitiesAnnotation;
import broccoli.entityrecognizer.annotations.PossibleEntityPronounAnnotation;
import broccoli.entityrecognizer.annotations
    .PossibleEntityClassTypeCoRefAnnotation;
import broccoli.entityrecognizer.disambiguation.Context;

/**
 * Tracks the current state of the entity recognizer.
 * 
 * @author bauschp, Manuel Ruder
 * 
 */
public class GeneralERStateTracker implements TrackableERState {
  /**
   * To differentiate pronouns.
   * 
   * @author haussmae
   * 
   */
  public enum PronounKind {
    /**
     * Female.
     */
    FEMALE,
    /**
     * Male.
     */
    MALE,
    /**
     * Other.
     */
    OTHER
  };

  /**
   * Constructor.
   */
  public GeneralERStateTracker() {
    this.activeEntities = new HashMap<String, SimpleBroccoliEntity>();
  }

  /**
   * A set of classes forbidden for common nouns.
   */
  private static Set<String> nonCommonNounClasses;

  static {
    nonCommonNounClasses = new HashSet<String>(); 
    nonCommonNounClasses.add("person");
    nonCommonNounClasses.add("location");
    nonCommonNounClasses.add("organisation");
    nonCommonNounClasses.add("writtenwork");
    nonCommonNounClasses.add("creativework");
    nonCommonNounClasses.add("film");
    nonCommonNounClasses.add("tvprogram");
    nonCommonNounClasses.add("tvepisode");
    nonCommonNounClasses.add("tvseason");
    nonCommonNounClasses.add("videogame");
    nonCommonNounClasses.add("workoffiction");
    nonCommonNounClasses.add("musicalalbum");
    nonCommonNounClasses.add("musicalrelease");
    nonCommonNounClasses.add("musicalrecording");
    // TODO(anyone): To be continued...
  }

  /**
   * The last entity that was recognized AND accepted (will be in words file). 
   */
  private SimpleBroccoliEntity lastEntity;

  /**
   * The entity that represents the document as best as possible.
   */
  private SimpleBroccoliEntity documentEntity;

  /**
   * All entities in the current context entities.
   */
  private HashMap<String, SimpleBroccoliEntity> activeEntities;

  /**
   * The last recognized person with gender male.
   */
  private SimpleBroccoliEntity lastMale = null;

  /**
   * The last recognized person with gender female.
   */
  private SimpleBroccoliEntity lastFemale = null;

  /**
   * Stores for each class the last entity that was recognized for this class.
   */
  private Map<String, SimpleBroccoliEntity> lastEntityForClass =
      new HashMap<String, SimpleBroccoliEntity>();

  /*
   * (non-Javadoc)
   * 
   * @see broccoli.entityrecognizer.TrackableERState#addEntity(broccoli.
   * entityrecognizer.data.SimpleBroccoliEntity)
   */
  @Override
  public void addEntity(SimpleBroccoliEntity entityInfo) {
    String uri = entityInfo.getBroccoliEntityName().substring(
      entityInfo.getBroccoliEntityName().lastIndexOf(':') + 1);
    // Segment entity in its words and add them to a list to
    // identify possible future references
    StringTokenizer st = new StringTokenizer(uri, "_");
    while (st.hasMoreTokens()) {
      String tok = st.nextToken();
      if (tok.length() > 3) {
        this.activeEntities.put(tok, entityInfo);
      }
    }
    lastEntity = entityInfo;
    if (entityInfo.isInstanceOf("person")
        && entityInfo.getGender() == SimpleBroccoliEntity.Gender.MALE) {
      lastMale = entityInfo;
    } else if (entityInfo.isInstanceOf("person")
        && entityInfo.getGender() == SimpleBroccoliEntity.Gender.FEMALE) {
      lastFemale = entityInfo;
    }
    for (String c : entityInfo.getClasses()) {
      lastEntityForClass.put(c, entityInfo);
    }
  }

  /*
   * (non-Javadoc)
   * 
   * @see broccoli.entityrecognizer.TrackableERState#reset()
   */
  @Override
  public void reset() {
    this.activeEntities.clear();
    this.lastEntity = null;
    this.documentEntity = null;
    this.lastEntityForClass.clear();
    this.lastMale = null;
    this.lastFemale = null;
  }

  /*
   * (non-Javadoc)
   * 
   * @see broccoli.entityrecognizer.TrackableERState#addDocumentEntity(broccoli
   * .entityrecognizer.data.SimpleBroccoliEntity)
   */
  @Override
  public void addDocumentEntity(SimpleBroccoliEntity entity) {
    this.documentEntity = entity;
    String title = entity.getBroccoliEntityName().substring(
      entity.getBroccoliEntityName().lastIndexOf(':') + 1);
    StringTokenizer st = new StringTokenizer(title, "_");
    while (st.hasMoreTokens()) {
      String tok = st.nextToken().toLowerCase();
      if (tok.length() > 3) {
        this.activeEntities.put(tok, entity);
      }
    }
    lastEntity = entity;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * broccoli.entityrecognizer.TrackableERState#getScore(broccoli
   * .entityrecognizer.data.SimpleBroccoliEntity)
   */
  @Override
  public int getScore(SimpleBroccoliEntity entity) {
    if (entity.getAbstractnessCount() >= 10) {
      return 0;
    } else {
      if (entity.equals(this.documentEntity)) {
        return 150;
      } else {
        return 1;
      }
    }
  }

  /**
   * Threshold factor for contextual aliases.
   */
  private static final int THRESHOLDFACTOR = 100;
  /**
   * Min similarity for contextual aliases.
   */
  private static final int MINSIMILARITY = 3;

  /**
   * Whether an entity is an instance of a non common noun class.
   */
  private boolean isInstanceOfNonCommonNounClass(SimpleBroccoliEntity entity) {
    for (String c : nonCommonNounClasses) {
      if (entity.isInstanceOf(c)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Use the maximal sequence of NNs and only recognize the whole sequence. This
   * should give a higher precision in exchange for lower recall.
   * 
   * @param surfaceLiteralMap
   * @param currentToken
   * @param entityRepository
   * @return
   */
  @Override
  public SimpleBroccoliEntity getEntityForCoarseContext(
      PossibleEntityAnnotation annotation,
      Context semanticContext,
      EntityDisambiguationDecisionMaker disambiguator) {
    SimpleBroccoliEntity best = null;  // The best entity for this context
    if (annotation instanceof PossibleEntityEntitiesAnnotation) {
      PossibleEntityEntitiesAnnotation annot =
          ((PossibleEntityEntitiesAnnotation) annotation);
      // Check if possible co-reference entity
      if (annotation.tokens != null && annotation.tokens.size() == 1) {
        best = this.activeEntities.get(
            annotation.tokens.get(0).getCoveredText());
        if (best != null) {
          return best;
        }
      }
      // Disambiguate entities
      if (annot.entities != null && annot.entities.size() > 0) {
        for (int i = 0; i < annot.entities.size(); ++i) {
          // Unnamed entities (common nouns) are not an instance of
          // specific classes
          if (annot.isCommonNoun
              && isInstanceOfNonCommonNounClass(annot.entities.get(i))) {
            continue;
          }
          if (best == null) {
            best = annot.entities.get(i);
          } else {
            best = disambiguator.disambiguateHomonym(
                best, annot.entities.get(i), semanticContext);
          }
        }
      }
      int bestScore = 0;
      if (best != null) {
        bestScore = best.getScore();
      }
      // Also check for possible contextual matches and disambiguate
      if (annot.possibleContextualMatches != null) {
        for (int i = 0; i < annot.possibleContextualMatches.size(); ++i) {
          // Contextual aliases are only valid in the entity specific semantic
          // context. So special restrictions for contextual aliases:
          // 1) If the score of the best entity is 100 times higher, skip.
          // 2) Contextual similarity must be higher than a specific min simila.
          SimpleBroccoliEntity e = annot.possibleContextualMatches.get(i);
          if ((e.getScore() * THRESHOLDFACTOR < bestScore)
              || (e.getContext().similarityTo(semanticContext)
                  <= MINSIMILARITY * e.getContext().computeAverage() + 0.001)) {
            continue;
          }
          if (best == null) {
            best = annot.possibleContextualMatches.get(i);
          } else {
            best = disambiguator.disambiguateHomonym(
                best, annot.possibleContextualMatches.get(i), semanticContext);
          }
        }
      }
    } else if (annotation instanceof PossibleEntityPronounAnnotation) {
      best = matchPronoun(
          ((PossibleEntityPronounAnnotation) annotation).pronounKind);
    } else if (annotation instanceof PossibleEntityClassTypeCoRefAnnotation) {
      best = handleClassOccurrence(
          ((PossibleEntityClassTypeCoRefAnnotation) annotation).possibleClass);
    }
    return best;
  }

  /**
   * @param maybeAClass
   * @return the matching entity or null
   */
  private SimpleBroccoliEntity handleClassOccurrence(String maybeAClass) {
    SimpleBroccoliEntity res = null;
    if (maybeAClass != null) {
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf(maybeAClass)) {
        res = this.documentEntity;
      }
      return lastEntityForClass.get(maybeAClass);
    }
    return null;
  }

  /**
   * 
   * @param pronounKind
   * @return a matching entity or null
   */
  private SimpleBroccoliEntity matchPronoun(PronounKind pronounKind) {
    if (pronounKind == PronounKind.MALE) {
      // A male person
      if (this.lastMale != null) {
        return this.lastMale;
      }
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf("person")
          && this.documentEntity.getGender()
              == SimpleBroccoliEntity.Gender.MALE) {
        return documentEntity;
      }
    } else if (pronounKind == PronounKind.FEMALE) {
      // A female person
      if (this.lastFemale != null) {
        return this.lastFemale;
      }
      if (this.documentEntity != null
          && this.documentEntity.isInstanceOf("person")
          && this.documentEntity.getGender()
              == SimpleBroccoliEntity.Gender.FEMALE) {
        return documentEntity;
      }
    } else {
      // No person
      if (this.lastEntity != null && !this.lastEntity.isInstanceOf("person")) {
        return lastEntity;
      }
      if (this.documentEntity != null
          && !this.documentEntity.isInstanceOf("person")) {
        return documentEntity;
      }
    }
    return null;
  }

  /**
   * @param s
   *          The string to modify
   * @return Parameter s with the first character made uppercase.
   * @param s
   * @return
   */
  private String firstCharUpper(String s) {
    return Character.toUpperCase(s.charAt(0)) + s.substring(1);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * broccoli.entityrecognizer.TrackableERState#recognizeDocumentEntity(java
   * .lang.String, broccoli.entityrecognizer.data.EntitySurfaceMap)
   */
  @Override
  public SimpleBroccoliEntity recognizeDocumentEntity(String title,
      AdvancedEntityRepository entityRepository) {
    // Tokenize the title. (maybe use the tokenizer for that as well.)
    List<String> words = Arrays.asList(title.split(" "));
    Set<SimpleBroccoliEntity> possibleEntities =
        new HashSet<SimpleBroccoliEntity>();
    for (int i = 0; i < words.size(); ++i) {
      String token = words.get(i);
      // Direct Match of entity with single token.
      List<SimpleBroccoliEntity> entities =
          entityRepository.getBroccoliEntitiesByAlias(token);
      if (entities != null) {
        for (SimpleBroccoliEntity ent : entities) {
          possibleEntities.add(ent);
        }
      }
      // Check 3 word combinations. TODO(anyone): improve this approach.
      for (int j = 2; j <= 3; ++j) {
        String check = token;
        for (int k = 0; k < j && k + i < words.size(); ++k) {
          check += " " + words.get(k + i);
        }
        entities = entityRepository.getBroccoliEntitiesByAlias(check);
        if (entities != null) {
          for (SimpleBroccoliEntity ent
              : entityRepository.getBroccoliEntitiesByAlias(check)) {
            possibleEntities.add(ent);
          }
        }
      }
    }
    // Get match with highest score.
    SimpleBroccoliEntity result = null;
    for (SimpleBroccoliEntity e : possibleEntities) {
      if (result == null || result.getScore() < e.getScore()) {
        result = e;
      }
    }
    return result;
  }

}
