// Copyright 2014 Philipp Bausch, Manuel Ruder
// <{bauschp,rudera}@informatik.uni-freiburg.de>

package broccoli.entityrecognizer;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import broccoli.entityrecognizer.annotations.EntityAnnotation;
import broccoli.entityrecognizer.annotations.PossibleEntityAnnotation;
import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.data.EntityRecognitionResult;
import broccoli.entityrecognizer.data.AdvancedEntityRepository;
import broccoli.uima.typesystem.Document;
import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.Sentence;
import broccoli.entityrecognizer.disambiguation.Context;

import org.apache.uima.cas.FSIterator;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;

/**
 * A generic entity recognizer that uses semantic similarity to recognize
 * entities, and is also able to recognize co-references.
 *  
 */
public class GeneralEntityRecognizer {

  /**
   * The complete entity repository.
   */
  private AdvancedEntityRepository entityRepository;

  /**
   * Used to disambiguate Entities.
   */
  private EntityDisambiguationDecisionMaker disambiguator;
  /**
   * Track the state of the current recognition process.
   */
  private TrackableERState recognizerState;

  /**
   * Upper-case classes.
   */
  private Set<String> uppercaseClasses;

  /**
   * The mention finder.
   */
  private MentionFinder mentionFinder;

  /**
   * Creates a new {@link EntityRecognizer}.
   * 
   * @param entityRepository
   *          The entity map that specifies the entities that are supported by
   *          Broccoli.
   */
  public GeneralEntityRecognizer(AdvancedEntityRepository entityRepository, 
      Set<String> uppercaseClasses, boolean recognizePronouns,
      boolean recognizeClassTypeCoRefs) {
    this.entityRepository = entityRepository;
    this.uppercaseClasses = uppercaseClasses;
    this.disambiguator = new DefaultDisambiguationRule();
    this.recognizerState = new GeneralERStateTracker();
    this.mentionFinder = new DefaultMentionFinder(recognizePronouns,
        recognizeClassTypeCoRefs);
    // this.mentionFinder = new NETagBasedMentionFinder(recognizePronouns,
    //    recognizeClassTypeCoRefs);  // Uses Stanford NER
    // this.mentionFinder = new IdealMentionFinder();  // ONLY for evaluation
  }

  /**
   * Creates a new {@link EntityRecognizer}.
   * 
   * @param entityRepository
   *          The entity map that specifies the entities that are supported by
   *          Broccoli.
   */
  public GeneralEntityRecognizer(AdvancedEntityRepository entityRepository, 
      Set<String> uppercaseClasses) {
    this(entityRepository, uppercaseClasses, true, true);
  }

  /**
   * The number of sentences before and after a sentence that should be included
   * in the context vector of the sentence.
   */
  private static final int K = 10;

  /**
   * The number of sentences of the beginning of the document that should always
   * be included in the context vector of each sentence.
   */
  private static final int TOP_K = 5;

  /**
   * Performs an entity recognition for the given annotated document.
   * 
   */
  public EntityRecognitionResult recognizeEntities(JCas jCas) {
    EntityRecognitionResult result = new EntityRecognitionResult();
    recognizerState.reset();
    // There should be only one element.
    FSIterator<Annotation> iter =
        jCas.getAnnotationIndex(Document.type).iterator();

    SimpleBroccoliEntity documentEntity = null;

    if (iter.isValid()) {
      Document doc = (Document) iter.get();
      documentEntity =
          this.recognizerState.recognizeDocumentEntity(
              doc.getTitle(), this.entityRepository);
    }

    List<EntityAnnotation> recognizedEntities =
        new ArrayList<EntityAnnotation>();

    // Determine the broccoli entity of the document if possible.
    if (documentEntity != null) {
      result.setDocumentEntityBroccoliString(documentEntity
          .getBroccoliEntityName());
    }

    List<Sentence> sentences = new ArrayList<Sentence>();
    List<List<PossibleEntityAnnotation> > mentions =
        new ArrayList<List<PossibleEntityAnnotation> >();

    // Iterate over all sentences to find entity mentions.
    for (iter = jCas.getAnnotationIndex(Sentence.type).iterator();
        iter.hasNext(); iter.next()) {
      Sentence sentence = (Sentence) iter.get();
      List<PossibleEntityAnnotation> erResults =
          mentionFinder.getEntitiesForSentence(
              sentence,                 // The current sentence.
              this.entityRepository);   // The entity repository.
      sentences.add(sentence);
      mentions.add(erResults);
    }

    Context context = new Context();
    for (int i = 0; i < sentences.size() && i < K; ++i) {
      context.addSentence(sentences.get(i), 1.0f);
    }

    // Iterate (again) over sentences to disambiguate entities.
    for (int i = 0; i <  sentences.size(); ++i) {
      // Adjust document context vector to current sentence
      if (i >= K + TOP_K) {
        context.subtractSentence(sentences.get(i - K), 1.0f, 0.1f);
      }
      if (i < sentences.size() - K) {
        context.addSentence(sentences.get(i + K), 1.0f);
      }
      for (int j = 0; j < mentions.get(i).size(); ++j) {
        SimpleBroccoliEntity entity =
            this.recognizerState.getEntityForCoarseContext(
                mentions.get(i).get(j),  // j-th mention of i-th sentence.
                context,                 // The context of this document.
                disambiguator);          // The disambiguation rule.
        if (entity != null) {
          boolean isCommonNoun = mentions.get(i).get(j).isCommonNoun;
          createAnnotation(recognizedEntities, entity,
              mentions.get(i).get(j).tokens,
              isCommonNoun);
          // Do not use common noun entities for finding co references.
          if (!isCommonNoun) {
            this.recognizerState.addEntity(entity);
          }
        }
      }
    }
    result.setRecognizedEntities(recognizedEntities);
    return result;
  }

  /**
   * Creates annotations for the last recognized Entity.
   */
  private void createAnnotation(List<EntityAnnotation> recognizedEntities,
      SimpleBroccoliEntity newEntity, List<Token> tokens,
      boolean isCommonNoun) {
    EntityAnnotation entityAnnotation = new EntityAnnotation(
        tokens.get(0).getBegin(), tokens.get(tokens.size() - 1).getEnd());
    // No overlap! Add annotation and continue with next token!
    entityAnnotation.setName(newEntity.getBroccoliEntityName());
    entityAnnotation.setScore(1);  //best.getScore());
    // Check whether this is a named entity or not.
    if (isCommonNoun) {
      entityAnnotation.setScore(0);
    }
    // add the annotation to the result list
    recognizedEntities.add(entityAnnotation);
  }
}
