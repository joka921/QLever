package broccoli.entityrecognizer;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

import broccoli.entityrecognizer.annotations.PossibleEntityAnnotation;
import broccoli.entityrecognizer.annotations.PossibleEntityPronounAnnotation;
import broccoli.entityrecognizer.annotations
    .PossibleEntityClassTypeCoRefAnnotation;
import broccoli.entityrecognizer.data.AdvancedEntityRepository;
import broccoli.entityrecognizer.GeneralERStateTracker.PronounKind;
import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.Sentence;

/**
 * An abstract class for mention finders.
 * 
 * @author Manuel Ruder
 * 
 */
public abstract class MentionFinder {

  /**
   * The map of pronouns to gender.
   */
  protected static Map<String, PronounKind> pronounMap;

  /**
   * A set of names that describe a unit of time.
   */
  protected static Set<String> unitOfTime;

  /**
   * The name of the definite article.
   */
  protected static final String DEFINITE_ARTICLE = "the";

  static {
    pronounMap = new HashMap<String, PronounKind>();
    pronounMap.put("he", PronounKind.MALE);
    pronounMap.put("his", PronounKind.MALE);
    pronounMap.put("him", PronounKind.MALE);
    pronounMap.put("himself", PronounKind.MALE);
    pronounMap.put("she", PronounKind.FEMALE);
    pronounMap.put("her", PronounKind.FEMALE);
    pronounMap.put("herself", PronounKind.FEMALE);
    pronounMap.put("it", PronounKind.OTHER);
    pronounMap.put("its", PronounKind.OTHER);
    pronounMap.put("itself", PronounKind.OTHER);
    unitOfTime = new HashSet<String>();
    unitOfTime.add("Monday");
    unitOfTime.add("Tuesday");
    unitOfTime.add("Wednesday");
    unitOfTime.add("Thursday");
    unitOfTime.add("Friday");
    unitOfTime.add("Saturday");
    unitOfTime.add("Sunday");
    unitOfTime.add("January");
    unitOfTime.add("February");
    unitOfTime.add("March");
    unitOfTime.add("April");
    unitOfTime.add("May");
    unitOfTime.add("June");
    unitOfTime.add("July");
    unitOfTime.add("August");
    unitOfTime.add("September");
    unitOfTime.add("October");
    unitOfTime.add("November");
    unitOfTime.add("December");
  }

  /**
   * Create a pronoun annotation.
   */
  protected static PossibleEntityPronounAnnotation createPronounAnnotation(
      Token token, PronounKind pronounKind) {
    PossibleEntityPronounAnnotation annotation =
        new PossibleEntityPronounAnnotation(token.getBegin(),
            token.getEnd());
    annotation.tokens = new ArrayList<Token>(1);
    annotation.tokens.add(token);
    annotation.pronounKind = pronounKind;
    return annotation;
  }

  /**
   * Create class type annotation.
   */
  protected static PossibleEntityClassTypeCoRefAnnotation
  createClassTypeAnnotation(Token dt, Token classType) {
    PossibleEntityClassTypeCoRefAnnotation annotation =
        new PossibleEntityClassTypeCoRefAnnotation(dt.getBegin(),
            classType.getEnd());
    annotation.tokens = new ArrayList<Token>(2);
    annotation.tokens.add(dt);
    annotation.tokens.add(classType);
    annotation.possibleClass = classType.getCoveredText();
    return annotation;
  }

  /**
   * Use the maximal sequence of NNs and only recognize the whole sequence.
   * This should give a higher precision in exchange for lower recall.
   * 
   * @param sentence
   * @param entityRepository
   * @return
   */
  public abstract List<PossibleEntityAnnotation> getEntitiesForSentence(
      Sentence sentence, AdvancedEntityRepository entityRepository);

  /**
   * Returns true if this token has to be checked for an Entity.
   * Rule of thumb Noun if POS-tagged. Otherwise \> 3 Characters.
   */
  protected static boolean isValidToken(Token token) {
    if (token.getCoveredText().length() == 0) {
      return false;
    }
    if (token.getPosTag() == null) {
      // fallback to ensure that this recognizer works, even if there
      // are no pos-tags.
      return token.getCoveredText().length() > 3;
    }
    // If the token is not a noun.
    if (!token.getPosTag().startsWith("N")) {
      return false;
    } else {
      String text = token.getCoveredText();
      // // For length 1 strings only if it is a character or digit.
      // Never recognize single letters.
      if (text.length() == 1) {
        // if (!Character.isLetterOrDigit(text.charAt(0))) {
        return false;
        // }
      }
      return true;
    }
  }
}
