package broccoli.entityrecognizer;

import java.util.ArrayList;

import broccoli.entityrecognizer.data.SimpleBroccoliEntity;
import broccoli.entityrecognizer.data.AdvancedEntityRepository;
import broccoli.entityrecognizer.annotations.PossibleEntityAnnotation;
// uima Token.
import broccoli.uima.typesystem.Token;
// import broccoli.uima.typesystem.Sentence;
import broccoli.entityrecognizer.disambiguation.Context;

/**
 * A general Interface that defines needed functionality to perform a entity
 * recognition task with the {@link GeneralEntityRecognizer}.
 * 
 * @author bauschp, rudera
 */
public interface TrackableERState {

  /**
   * A simple result container.
   * 
   * @author haussmae
   * 
   */
  public class ERResult {
    /**
     * The recognized entities.
     */
    public SimpleBroccoliEntity entities;

    /**
     * The tokens on which the entity was recognized.
     */
    public ArrayList<Token> tokens = new ArrayList<Token>();
  }

  /**
   * @param entityInfo
   */
  void addEntity(SimpleBroccoliEntity entityInfo);

  /**
   *
   */
  void reset();

  /**
   * @param documentEntityBroccoliString
   */
  void addDocumentEntity(SimpleBroccoliEntity entity);

  /**
   * This method provides a new scoring method to score entities in each
   * document differently. e.g. (A document about Albert Einstein could
   * increase the score for Albert Einstein).
   */
  int getScore(SimpleBroccoliEntity entity);

  /**
   * This method should try to recognize entities in the neigbourhood of
   * given token. <b>Because it is called frequently it should be fast!</b>
   * Remember tokens to be able to judge over neighbourhood.
   */
  SimpleBroccoliEntity getEntityForCoarseContext(
      PossibleEntityAnnotation annotation,
      Context semanticContext,
      EntityDisambiguationDecisionMaker disambiguator);
  /**
   * Recognizes an Entity in the Title.
   */
  SimpleBroccoliEntity recognizeDocumentEntity(String title,
      AdvancedEntityRepository entityRepository);

}
