package broccoli.entityrecognizer.annotations;

/**
 * An annotation to abstract from the UIMA annotations.
 * 
 * @author Florian Bäurle
 */
public class Annotation {

  /**
   * The begin position of the annotation.
   */
  private int begin;
  /**
   * The end position of the annotation.
   */
  private int end;

  /**
   * Creates a new {@link Annotation} with the given begin and end positions.
   * 
   * @param begin
   *          The begin position of the annotation.
   * @param end
   *          The end position of the annotation.
   */
  public Annotation(int begin, int end) {
    this.begin = begin;
    this.end = end;
  }

  /**
   * Gets the begin position of the annotation.
   * 
   * @return The begin position of the annotation.
   */
  public int getBegin() {
    return this.begin;
  }

  /**
   * Gets the end position of the annotation.
   * 
   * @return The end position of the annotation.
   */
  public int getEnd() {
    return this.end;
  }

  /**
   * Checks if this annotation lies inside the range of another annotation.
   * 
   * @param otherAnnotation
   *          The other annotation to check if this annotation is contained in.
   * @return <code>true</code> if this annotation lies inside of the range of
   *         the other annotation, <code>false</code> otherwise.
   */
  public boolean isContainedIn(Annotation otherAnnotation) {
    return (this.begin >= otherAnnotation.begin)
        && (this.end <= otherAnnotation.end);
  }
}
