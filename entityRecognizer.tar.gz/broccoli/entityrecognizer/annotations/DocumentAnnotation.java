package broccoli.entityrecognizer.annotations;

/**
 * A document annotation.
 * 
 * @author Florian Bäurle
 */
public class DocumentAnnotation extends Annotation {

  /**
   * The title of the document.
   */
  private String title;
  /**
   * The complete text of the document.
   */
  private String text;

  /**
   * Creates a new {@link DocumentAnnotation}.
   * 
   * @param begin
   *          The begin position of the document annotation.
   * @param end
   *          The end position of the document annotation.
   */
  public DocumentAnnotation(int begin, int end) {
    super(begin, end);
  }

  /**
   * Creates a new {@link DocumentAnnotation} with the given values.
   * 
   * @param begin
   *          The begin position of the document annotation.
   * @param end
   *          The end position of the document annotation.
   * @param title
   *          The title of the document.
   * @param text
   *          The complete text of the document.
   */
  public DocumentAnnotation(int begin, int end, String title, String text) {
    super(begin, end);

    this.title = title;
    this.text = text;
  }

  /**
   * Gets the title of the document.
   * 
   * @return The title of the document.
   */
  public String getTitle() {
    return this.title;
  }

  /**
   * Sets the title of the document.
   * 
   * @param title
   *          The title of the document.
   */
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   * Gets the complete text of the document.
   * 
   * @return The complete text of the document.
   */
  public String getText() {
    return this.text;
  }

  /**
   * Sets the complete text of the document.
   * 
   * @param text
   *          The complete text of the document.
   */
  public void setText(String text) {
    this.text = text;
  }
}
