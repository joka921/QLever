package broccoli.entityrecognizer.annotations;

/**
 * An entity annotation.
 * 
 * @author Florian Bäurle
 */
public class EntityAnnotation extends Annotation {

  /**
   * The broccoli name of the entity.
   */
  private String name;
  /**
   * The score of the entity.
   */
  private int score;

  /**
   * Creates a new {@link EntityAnnotation}.
   * 
   * @param begin
   *          The begin position of the entity annotation.
   * @param end
   *          The end position of the entity annotation.
   */
  public EntityAnnotation(int begin, int end) {
    super(begin, end);
  }

  /**
   * Creates a new {@link EntityAnnotation} with the given values.
   * 
   * @param begin
   *          The begin position of the entity annotation.
   * @param end
   *          The end position of the entity annotation.
   * @param name
   *          The broccoli name of the entity.
   * @param score
   *          The score of the entity.
   */
  public EntityAnnotation(int begin, int end, String name, int score) {
    super(begin, end);

    this.name = name;
    this.score = score;
  }

  /**
   * Gets the broccoli name of the entity.
   * 
   * @return The broccoli name of the entity.
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the broccoli name of the entity.
   * 
   * @param name
   *          The broccoli name of the entity.
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the score of the entity.
   * 
   * @return The score of the entity.
   */
  public int getScore() {
    return this.score;
  }

  /**
   * Sets the score of the entity.
   * 
   * @param score
   *          The score of the entity.
   */
  public void setScore(int score) {
    this.score = score;
  }
}
