package broccoli.entityrecognizer.annotations;

import java.util.List;
import broccoli.uima.typesystem.Token;

/**
 * An annotation of a passage in the text where a possible entity was detected.
 * 
 * @author Manuel Ruder
 */
public class PossibleEntityAnnotation extends Annotation {

  /**
   * The tokens that belong to this passage.
   */
  public List<Token> tokens = null;

  /**
   * Whether this is a common noun or a proper noun.
   */
  public boolean isCommonNoun = false;

  /**
   * Creates a new {@link PossibleEntitiesAnnotation}.
   * 
   * @param begin
   *          The begin position of the annotation.
   * @param end
   *          The end position of the annotation.
   */
  public PossibleEntityAnnotation(int begin, int end) {
    super(begin, end);
  }

}
