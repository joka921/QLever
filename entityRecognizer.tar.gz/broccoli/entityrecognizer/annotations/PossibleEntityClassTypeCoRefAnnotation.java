package broccoli.entityrecognizer.annotations;

/**
 * An annotation of a passage in the text where a pronoun was detected.
 * 
 * @author Manuel Ruder
 */
public class PossibleEntityClassTypeCoRefAnnotation
    extends PossibleEntityAnnotation {

  /**
   * The possible class.
   */
  public String possibleClass = "";

  /**
   * Creates a new {@link PossibleEntitiesAnnotation}.
   * 
   * @param begin
   *          The begin position of the annotation.
   * @param end
   *          The end position of the annotation.
   */
  public PossibleEntityClassTypeCoRefAnnotation(int begin, int end) {
    super(begin, end);
  }

}
