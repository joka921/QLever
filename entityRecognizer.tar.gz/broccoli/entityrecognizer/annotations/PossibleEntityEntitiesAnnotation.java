package broccoli.entityrecognizer.annotations;

import java.util.List;
import broccoli.entityrecognizer.data.SimpleBroccoliEntity;

/**
 * An annotation of a passage in the text where (multiple) entities detected.
 * 
 * @author Manuel Ruder
 */
public class PossibleEntityEntitiesAnnotation extends PossibleEntityAnnotation {

  /**
   * The possible entities that were detected at this passage.
   */
  public List<SimpleBroccoliEntity> entities = null;

  /**
   * The possible contextual entities that were detected at this passage.
   */
  public List<SimpleBroccoliEntity> possibleContextualMatches = null;

  /**
   * Creates a new {@link PossibleEntitiesAnnotation}.
   * 
   * @param begin
   *          The begin position of the annotation.
   * @param end
   *          The end position of the annotation.
   */
  public PossibleEntityEntitiesAnnotation(int begin, int end) {
    super(begin, end);
  }

}
