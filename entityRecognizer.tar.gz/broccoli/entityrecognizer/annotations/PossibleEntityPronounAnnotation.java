package broccoli.entityrecognizer.annotations;

import broccoli.entityrecognizer.GeneralERStateTracker.PronounKind;

/**
 * An annotation of a passage in the text where a pronoun was detected.
 * 
 * @author Manuel Ruder
 */
public class PossibleEntityPronounAnnotation extends PossibleEntityAnnotation {

  /**
   * The pronoun kind.
   */
  public PronounKind pronounKind;

  /**
   * Creates a new {@link PossibleEntitiesAnnotation}.
   * 
   * @param begin
   *          The begin position of the annotation.
   * @param end
   *          The end position of the annotation.
   */
  public PossibleEntityPronounAnnotation(int begin, int end) {
    super(begin, end);
  }

}
