package broccoli.entityrecognizer.annotations;

/**
 * A section annotation.
 * 
 * @author Florian Bäurle
 * 
 */
public class SectionAnnotation extends Annotation {

  /**
   * The headline of the section.
   */
  private String headline;
  /**
   * The level of the section.
   */
  private int level;

  /**
   * Creates a new {@link SectionAnnotation}.
   * 
   * @param begin
   *          The begin position of the section annotation.
   * @param end
   *          The end position of the section annotation.
   */
  public SectionAnnotation(int begin, int end) {
    super(begin, end);
  }

  /**
   * Creates a new {@link SectionAnnotation} with the given values.
   * 
   * @param begin
   *          The begin position of the section annotation.
   * @param end
   *          The end position of the section annotation.
   * @param headline
   *          The headline of the section.
   * @param level
   *          The level of the section.
   */
  public SectionAnnotation(int begin, int end, String headline, int level) {
    super(begin, end);

    this.headline = headline;
    this.level = level;
  }

  /**
   * Gets the headline of the section.
   * 
   * @return The headline of the section.
   */
  public String getHeadline() {
    return this.headline;
  }

  /**
   * Sets the headline of the section.
   * 
   * @param headline
   *          The headline of the section.
   */
  public void setHeadline(String headline) {
    this.headline = headline;
  }

  /**
   * Gets the level of the section.
   * 
   * @return The level of the section.
   */
  public int getLevel() {
    return this.level;
  }

  /**
   * Sets the level of the section.
   * 
   * @param level
   *          The level of the section.
   */
  public void setLevel(int level) {
    this.level = level;
  }
}
