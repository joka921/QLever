package broccoli.entityrecognizer.annotations;

/**
 * A Token annotation.
 * 
 * @author Florian Bäurle
 */
public class TokenAnnotation extends Annotation {

  /**
   * The text covered by the token.
   */
  private String coveredText;

  /**
   * Creates a new {@link TokenAnnotation} with the given values.
   * 
   * @param begin
   *          The begin position of the Token annotation.
   * @param end
   *          The end position of the Token annotation.
   * @param coveredText
   *          The text covered by the Token.
   */
  public TokenAnnotation(int begin, int end, String coveredText) {
    super(begin, end);

    this.coveredText = coveredText;
  }

  /**
   * Gets text covered by the token.
   * 
   * @return The text covered by the token.
   */
  public String getCoveredText() {
    return this.coveredText;
  }
}
