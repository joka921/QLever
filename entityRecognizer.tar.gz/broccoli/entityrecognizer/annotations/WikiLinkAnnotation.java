package broccoli.entityrecognizer.annotations;

/**
 * A Wikipedia link annotation.
 * 
 * @author Florian Bäurle
 */
public class WikiLinkAnnotation extends Annotation {

  /**
   * The target article name of the Wikipedia link.
   */
  private String target;

  /**
   * Creates a new {@link WikiLinkAnnotation} with the given values.
   * 
   * @param begin
   *          The begin position of the Wikipedia link annotation.
   * @param end
   *          The end position of the Wikipedia link annotation.
   * @param target
   *          The target article name of the Wikipedia link.
   */
  public WikiLinkAnnotation(int begin, int end, String target) {
    super(begin, end);

    this.target = target;
  }

  /**
   * Gets the target article name of the Wikipedia link.
   * 
   * @return The target article name of the Wikipedia link.
   */
  public String getTarget() {
    return this.target;
  }
}
