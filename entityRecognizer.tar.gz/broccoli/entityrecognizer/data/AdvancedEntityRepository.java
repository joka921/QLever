package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.Collection;

import broccoli.utility.EntityNameNormalizer;

/**
 * A simple repository of all entities supported by the entity recognition.
 * The central container is a map from entity name to the corresponding
 * BroccoliEntity object.
 * Similar to EntityRepository, but does not count or track unique alias names.
 * 
 * 
 * @author Elmar Haussmann, Manuel Ruder
 */
public class AdvancedEntityRepository {

  /**
   * A map from entity name to corresponding entity.
   */
  private Map<String, SimpleBroccoliEntity> entityNameMap;
  
  /**
   * A map from entity alias name to corresponding entities.
   * (Aliases are not unique)
   */
  private Map<String, ArrayList<SimpleBroccoliEntity> > entityAliasMap;
  
  /**
   * A map from entity contextual alias to corresponding entities.
   * Contextual aliases are only valid in the entity specific semantic context.
   * (Needs further contextual checks in entity recognition)
   */
  private Map<String, ArrayList<SimpleBroccoliEntity> > contextualAliasMap;

  /**
   * 
   * @return
   */
  public Collection<SimpleBroccoliEntity> getEntities() {
    return entityNameMap.values();
  }

  /**
   * A map from word to its score, indicating how concrete the word is.
   */
  private HashMap<String, Double> wordConcretenessScores = 
      new HashMap<String, Double>();

  /**
   * A number format for the progress percentage.
   */
  private NumberFormat percentFormat = NumberFormat.getPercentInstance();

  /**
   * Maximum number of warnings to print.
   */
  private static final int MAX_NOF_WARNINGS = 15;

  /**
   * Creates a new {@link EntityRepository} from the provided files.
   * 
   * @param wordConcretenessFile
   * 
   */
  public AdvancedEntityRepository(String broccoliEntitiesFile,
      String wordConcretenessFile, String semanticContextFile)
    throws IOException, ParseException {
    // configure the number format for the progress percentage
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);

    this.entityNameMap =
        new HashMap<String, SimpleBroccoliEntity>(30000000, 0.75f);
    this.entityAliasMap =
        new HashMap<String, ArrayList<SimpleBroccoliEntity> >(60000000, 0.75f);
    this.contextualAliasMap =
        new HashMap<String, ArrayList<SimpleBroccoliEntity> >(6000000, 0.75f);
    
    readWordConcreteness(wordConcretenessFile);

    readBroccoliEntities(broccoliEntitiesFile);

    readSemanticContextFile(semanticContextFile);

    System.out.println("... finished creating the Broccoli entity list!");
  }

  /**
   * Read the given semantic context file.
   */
  private void readSemanticContextFile(String contextFileName)
    throws IOException, ParseException  {
    int nofWarningsWritten = 0;
    int nofUnknownEntities = 0;
    System.out.println("Reading semantic context from " + contextFileName
        + ".");
    File file =  new File(contextFileName);
    FileInputStream stream = new FileInputStream(file);
    InputStreamReader streamReader = new InputStreamReader(stream, "UTF-8");
    BufferedReader reader = new BufferedReader(streamReader);
    int lineCount = 0;
    String line;
    while ((line = reader.readLine()) != null) {
      ++lineCount;
      String[] columns = line.split("\t");
      if (columns.length % 2 != 1) {
        throw new ParseException(
            "The provided semantic context file contains "
                + "an invalid number of columns!", lineCount);
      }
      SimpleBroccoliEntity entity = entityNameMap.get(
          EntityNameNormalizer.normalize(columns[0]));
      if (entity == null) {
        if (nofWarningsWritten < MAX_NOF_WARNINGS) {
          System.out.println("WARNING: The provided semantic context file "   
              + "contains an unknown entity name: " + columns[0]);
          ++nofWarningsWritten;
        } else {
          if (nofWarningsWritten == MAX_NOF_WARNINGS) {
            System.out.println("WARNING: There are more unknown entities, "
                + "suppressing warnings...");
            ++nofWarningsWritten;
          }
        }
        nofUnknownEntities++;
        continue;
      }
      boolean couldBeAlias = true;
      entity.getContext().setUp(columns.length / 2);
      // Table format is: word<tab>score<tab>word<tab>score...
      for (int i = 1; i < columns.length - 1; i += 2) {
        // Only substrings of the entity name that have a higher score than the
        // entity name itself will be recognized as alias.
        if (columns[i].equals(columns[0])) {
          couldBeAlias = false;
          continue;
        }
        // If this word is a substring of the entity name, it may be an alias.
        if (columns[0].contains(columns[i])) {
          if (couldBeAlias && Character.isUpperCase(columns[i].charAt(0))) {
            ArrayList<SimpleBroccoliEntity> list =
                this.entityAliasMap.get(columns[i]);
            // Check if it's already regular alias.
            if (list != null && list.contains(entity)) {
              continue;
            }
            list = this.contextualAliasMap.get(columns[i]);
            if (list == null) {
              list = new ArrayList<SimpleBroccoliEntity>(1);
              this.contextualAliasMap.put(columns[i], list);
            }
            list.add(entity);
          }
          continue;
        }
        entity.getContext().addFeature(columns[i],
            Float.parseFloat(columns[i + 1]));
      }
      // Normalisation is expensive...
      // entity.getContext().normalize();
    }
    reader.close();
    System.out.println("Done." + (nofUnknownEntities == 0 ? "" : " ("
        + nofUnknownEntities + " unknown entities)"));
  }

  /**
   * Read word concreteness file.
   * @param wordConcretenessFile
   * @throws IOException
   * @throws ParseException
   */
  private void readWordConcreteness(String wordConcretenessFile)
    throws IOException, ParseException {
    // TODO Auto-generated method stub
    System.out.println("Reading word concreteness from " + wordConcretenessFile
        + ".");
    File abstractsFile =  new File(wordConcretenessFile);
    FileInputStream abstractsStream = new FileInputStream(abstractsFile);
    InputStreamReader abstractsStreamReader = new InputStreamReader(
        abstractsStream, "UTF-8");
    BufferedReader abstractsReader = new BufferedReader(abstractsStreamReader);
    int lineCount = 0;
    String line;
    while ((line = abstractsReader.readLine()) != null) {
      ++lineCount;
      String[] columns = line.split("\t");
      if (columns.length != 2) {
        throw new ParseException(
            "The provided word concreteness file contains "
                + "an invalid number of columns!", lineCount);
      }
      this.wordConcretenessScores.put(columns[0], Double.valueOf(columns[1]));
    }
    abstractsReader.close();
    System.out.println("Done (" + this.wordConcretenessScores.size() 
        + " elements).");
  }

  /**
   * 
   * @param abstractnessCountsFile
   * @throws IOException
   * @throws ParseException
   */
  private void readAbstractnessCounts(String abstractnessCountsFile)
    throws IOException, ParseException {
    String line;
    long startTime;
    int lineCount;
    int nofWarningsWritten = 0;

    System.out.println("\tReading the abstractness counts file:");

    File abstractsFile = new File(abstractnessCountsFile);
    FileInputStream abstractsStream = new FileInputStream(abstractsFile);
    InputStreamReader abstractsStreamReader = new InputStreamReader(
        abstractsStream, "UTF-8");
    BufferedReader abstractsReader = new BufferedReader(abstractsStreamReader);
    startTime = System.currentTimeMillis();
    lineCount = 0;
    while ((line = abstractsReader.readLine()) != null) {
      ++lineCount;

      int indexOfTab = line.indexOf('\t');
      int abstractnessCount;
      try {
        abstractnessCount = Integer.parseInt(line.substring(0, indexOfTab));
      } catch (NumberFormatException e) {
        throw new ParseException(
            "The provided abstractness counts file contains "
                + "an invalid number!", lineCount);
      }
      String broccoliEntityString = line.substring(indexOfTab + 1);
      if ((abstractnessCount < 0) || broccoliEntityString.isEmpty()) {
        throw new ParseException(
            "The provided abstractness counts file has invalid content!",
            lineCount);
      }

      int lastIndexofColon = broccoliEntityString.lastIndexOf(':');
      // make sure that the entity name is normalized, even though it normally
      // must be already
      String normalizedEntityName = EntityNameNormalizer
          .normalize(broccoliEntityString.substring(lastIndexofColon + 1));

      // set the abstractness count of the entity in the map in its entity info
      SimpleBroccoliEntity entity =
          this.entityNameMap.get(normalizedEntityName);
      if (entity != null) {
        if (entity.getAbstractnessCount() > 0
            && nofWarningsWritten < MAX_NOF_WARNINGS) {
          System.out
              .println("WARNING: The provided abstractness counts file had a "
                  + "duplicate entry for '" + normalizedEntityName
                  + "'! The previous number was overwritten!");
          nofWarningsWritten++;
        }
        entity.setAbstractnessCount(abstractnessCount);
      } else if (nofWarningsWritten < MAX_NOF_WARNINGS) {
        System.out
            .println("WARNING: The provided abstractness counts file had an "
                + "entry for '" + normalizedEntityName
                + "' which was not contained in the known entities!");
        nofWarningsWritten++;
      } else if (nofWarningsWritten == MAX_NOF_WARNINGS) {
        System.out.println("WARNING: Suppressing additional warnings...");
        nofWarningsWritten++;
      }
    }
    abstractsReader.close();

    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");
  }

  /**
   * 
   * @param ontologyEntityListFile
   * @throws IOException
   * @throws ParseException
   */
  private void readBroccoliEntities(String ontologyEntityListFile)
    throws IOException, ParseException {
    // define helper variables for temp values and measurements
    String line;
    long startTime;
    long lastTimeDif;
    int lineCount;
    long totalFileBytes;
    long readFileBytes = 0;
    int nofWarningsWritten = 0;

    System.out.println("\tReading the ontology entity file from: "
        + ontologyEntityListFile);

    File listFile = new File(ontologyEntityListFile);
    FileInputStream listStream = new FileInputStream(listFile);
    InputStreamReader listStreamReader = new InputStreamReader(listStream,
        "UTF-8");
    BufferedReader listReader = new BufferedReader(listStreamReader);
    startTime = System.currentTimeMillis();
    lastTimeDif = 0;
    lineCount = 0;
    totalFileBytes = listFile.length();

    while ((line = listReader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 500000 == 0) {
        long currentTimeDif = System.currentTimeMillis() - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + this.percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      // File is tab separated: entityname, classes, aliasnames.
      String[] columns = line.split("\t");

      // Empty entityname or classes is not allowed.
      if (columns.length < 4 || columns[0].isEmpty() || columns[1].isEmpty()) {
        listReader.close();
        throw new ParseException(
            "The provided ontology entity list file has invalid content!",
            lineCount);
      }
      String broccoliEntityName = columns[0];
      String classesString = columns[1];
      int score = Integer.valueOf(columns[2]);
      int abstractnessCount = Integer.valueOf(columns[3]);
      
      // The classes are comma-separated. Split them.
      Set<String> classesSet = new HashSet<String>();
      if (classesString.contains(",")) {
        String[] classes = classesString.split(",");
        for (String classString : classes) {
          // make sure to use the same string references for equal classes to
          // reduce the amount of needed memory
          if (!classString.isEmpty()) {
            classesSet.add(classString.intern());
          }
        }
      } else {
        classesSet.add(classesString.intern());
      }

      SimpleBroccoliEntity temp = this.entityNameMap.get(broccoliEntityName);
      // Check for duplicate entity.
      if (temp == null) {
        // create the broccoli entity info object
        SimpleBroccoliEntity entity = new SimpleBroccoliEntity(
            broccoliEntityName, classesSet, score, abstractnessCount);
        // Add the entity's alias names.
        // The remaining columns are the aliases.
        for (int c = 4; c < columns.length; ++c) {
          // Normalize alias name to fix misformated names in ontology database.
          String aliasName = EntityNameNormalizer.normalize(columns[c]);
          if (!aliasName.isEmpty()) {
            addAliasForEntity(entity, aliasName, false);
          }
        }
        addAliasForEntity(entity, broccoliEntityName, true);
        this.entityNameMap.put(broccoliEntityName, entity);
      } else {
        if (nofWarningsWritten < MAX_NOF_WARNINGS) {
          System.out.println("WARNING: The provided ontology entity "
              + "file had a duplicate entry for '" + broccoliEntityName
              + "'! Ignoring duplicate entry.");
          ++nofWarningsWritten;
        } else {
          if (nofWarningsWritten == MAX_NOF_WARNINGS) {
            System.out.println("WARNING: There are more duplicate entries, "
                + "suppressing warnings...");
            ++nofWarningsWritten;
          }
        }
      }

    }
    listReader.close();
    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");
  }
  
  /**
   * Add alias for entity.
   */
  private void addAliasForEntity(SimpleBroccoliEntity entity, String aliasName,
      boolean duplicateCheck) {
    // Try get already existing list for this alias.
    ArrayList<SimpleBroccoliEntity> list = this.entityAliasMap.get(aliasName);
    if (list == null) {
      list = new ArrayList<SimpleBroccoliEntity>(1);
      this.entityAliasMap.put(aliasName, list);
    }
    if (duplicateCheck && list.contains(entity)) {
      return;
    }
    list.add(entity);
  }

  /**
   * Checks if the given entity is contained.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @return <code>true</code> if the entity is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsEntity(String entityName) {
    return this.entityNameMap.containsKey(EntityNameNormalizer
        .normalize(entityName));
  }

  /**
   * Gets the entity for a surface text, but does not normalize the surface
   * text.
   * 
   */
  public SimpleBroccoliEntity getBroccoliEntityExact(String surfaceText) {
    return this.entityNameMap.get(surfaceText);
  }

  /**
   * Gets the entity for a surface text.
   * 
   */
  public SimpleBroccoliEntity getBroccoliEntity(String surfaceText) {
    return this.entityNameMap.get(EntityNameNormalizer.normalize(surfaceText));
  }
  
  /**
   * Gets the entities for a surface text by entity alias names.
   * 
   */
  public ArrayList<SimpleBroccoliEntity> getBroccoliEntitiesByAlias(
      String surfaceText) {
    return this.entityAliasMap.get(EntityNameNormalizer.normalize(surfaceText));
  }
  
  /**
   * Gets the entities for a surface text by entity alias names.
   * 
   */
  public ArrayList<SimpleBroccoliEntity> getBroccoliEntitiesByContextualAlias(
      String surfaceText) {
    return this.contextualAliasMap.get(
        EntityNameNormalizer.normalize(surfaceText));
  }
  
  /**
   * Return the concretenss score if word found 
   * or 1.0 if not found. 
   * @param word
   * @return
   */
  public double getWordConcreteness(String word) {
    if (this.wordConcretenessScores.containsKey(word)) {
      return this.wordConcretenessScores.get(word);
    } else {
      return 1.0;
    }
  }
  
}
