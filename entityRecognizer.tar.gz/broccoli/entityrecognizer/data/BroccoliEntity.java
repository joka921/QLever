package broccoli.entityrecognizer.data;

import java.util.HashSet;
import java.util.Set;

/**
 * An entity that can be recognized in text and is part of the broccoli 
 * ontology.
 * 
 * @author Florian Bäurle, Elmar Haussmann
 */
public class BroccoliEntity {

  
  /**
   * Persons have a gender.
   *
   */
  public enum Gender {
    /**
     * Male.
     */
    MALE, 
    /**
     * Female.
     */
    FEMALE
  };

  /**
   * The gender of the entity, if it is a person.
   */
  private Gender gender;

  /**
   * The entity name that identifies the entity in the broccoli ontology.
   */
  private String broccoliEntityName;
  
  /**
   * A set containing the classes the entity is an instance of.
   */
  private Set<String> classes;
  
  /**
   * A set containing the aliase names/alternative spellings of this entity.
   */
  private Set<String> aliases;

  /**
   * The abstractness count of the entity.
   */
  private int abstractnessCount;
  
  /**
   * Name of the special class for female gender.
   */
  private static final String FEMALE_GENDER_CLASS = "gender_female";
  
  /**
   * Name of the special class for male gender.
   */
  private static final String MALE_GENDER_CLASS = "gender_male";
 
  
  /**
   * The score of the entity.
   */
  private int score;

  /**
   * Creates a new {@link BroccoliEntity}.
   * 
   * @param broccoliEntityString
   *          The Broccoli string representation of the entity.
   * @param classes
   *          A set containing the classes the entity is an instance of.
   */
  public BroccoliEntity(String broccoliEntityString, Set<String> classes) {
    new BroccoliEntity(broccoliEntityString, classes, 0, 0);
  }
  
  /**
   * Creates a new {@link BroccoliEntity}.
   * 
   * @param broccoliEntityString
   *          The Broccoli string representation of the entity.
   * @param classes
   *          A set containing the classes the entity is an instance of.
   */
  public BroccoliEntity(String broccoliEntityString, Set<String> classes,
      int score, int abstractnessCount) {
    this.score = score;
    this.abstractnessCount = abstractnessCount;
    this.broccoliEntityName = broccoliEntityString;
    this.classes = classes;
    this.aliases = new HashSet<String>();
    // Set the gender.
    if (isInstanceOf(FEMALE_GENDER_CLASS)) {
      this.gender = Gender.FEMALE;
    } else if (isInstanceOf(MALE_GENDER_CLASS)) {
      this.gender = Gender.MALE;
    }
  }

  // /**
  // * Gets the name of the entity. (The substring after the last colon in the
  // * broccoli entity string.)
  // *
  // * @return The name of the entity.
  // */
  // public String getEntityName() {
  // int lastColonIndex = this.broccoliEntityString.lastIndexOf(':');
  // return this.broccoliEntityString.substring(lastColonIndex + 1);
  // }

  /**
   * Gets the Broccoli string representation of the entity.
   * 
   * @return The Broccoli string representation of the entity.
   */
  public String getBroccoliEntityName() {
    return this.broccoliEntityName;
  }

  /**
   * Gets a copy of the set which contains the classes the entity is an instance
   * of.
   * 
   * @return A copy of the set which contains the classes the entity is an
   *         instance of.
   */
  public Set<String> getClasses() {
    return new HashSet<String>(this.classes);
  }

  /**
   * Determines if this entity is an instance of the provided class.
   * 
   * @param classString
   *          The name of the class to check if the entity is an instance of.
   * @return <code>true</code> if the entity is an instance of the given class,
   *         <code>false</code> otherwise.
   */
  public boolean isInstanceOf(String classString) {
    return this.classes.contains(classString);
  }

  /**
   * Gets the abstractness count of the entity.
   * 
   * @return The abstractness count of the entity.
   */
  public int getAbstractnessCount() {
    return abstractnessCount;
  }

  /**
   * Sets the abstractness count of the entity.
   * 
   * @param abstractnessCount
   *          The abstractness count of the entity.
   */
  public void setAbstractnessCount(int abstractnessCount) {
    this.abstractnessCount = abstractnessCount;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof BroccoliEntity) {
      return this.broccoliEntityName.equals(((BroccoliEntity) obj)
          .getBroccoliEntityName());
    }
    return false;
  }

  @Override
  public int hashCode() {
    return this.broccoliEntityName.hashCode();
  }
  
  /**
   * Add an alias.
   * @param alias
   */
  public void addAlias(String alias) {
    this.aliases.add(alias);
  }
  
  /**
   * Get the aliases.
   * @return
   */
  public Set<String> getAliases() {
    return this.aliases;
  }

  /**
   * 
   * @return
   */
  public int getScore() {
    return score;
  }

  /**
   * 
   * @param score
   */
  public void setScore(int score) {
    this.score = score;
  }
  
  /**
   * Get the gender - only valid values for a person.
   * @return
   */
  public Gender getGender() {
    return this.gender;
  }
  
}
