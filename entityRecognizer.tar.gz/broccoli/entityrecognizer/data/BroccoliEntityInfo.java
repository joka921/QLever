package broccoli.entityrecognizer.data;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents the information about an entity that is available from Broccoli.
 * 
 * @author Florian Bäurle
 */
public class BroccoliEntityInfo {

  /**
   * The Broccoli string representation of the entity.
   */
  private String broccoliEntityString;
  /**
   * A set containing the classes the entity is an instance of.
   */
  private Set<String> classes;

  /**
   * The abstractness count of the entity.
   */
  private int abstractnessCount;

  /**
   * Creates a new {@link BroccoliEntityInfo}.
   * 
   * @param broccoliEntityString
   *          The Broccoli string representation of the entity.
   * @param classes
   *          A set containing the classes the entity is an instance of.
   */
  public BroccoliEntityInfo(String broccoliEntityString, Set<String> classes) {
    this.broccoliEntityString = broccoliEntityString;
    this.classes = classes;
  }

  // /**
  // * Gets the name of the entity. (The substring after the last colon in the
  // * broccoli entity string.)
  // *
  // * @return The name of the entity.
  // */
  // public String getEntityName() {
  // int lastColonIndex = this.broccoliEntityString.lastIndexOf(':');
  // return this.broccoliEntityString.substring(lastColonIndex + 1);
  // }

  /**
   * Gets the Broccoli string representation of the entity.
   * 
   * @return The Broccoli string representation of the entity.
   */
  public String getBroccoliEntityString() {
    return this.broccoliEntityString;
  }

  /**
   * Gets a copy of the set which contains the classes the entity is an instance
   * of.
   * 
   * @return A copy of the set which contains the classes the entity is an
   *         instance of.
   */
  public Set<String> getClasses() {
    return new HashSet<String>(this.classes);
  }

  /**
   * Determines if this entity is an instance of the provided class.
   * 
   * @param classString
   *          The name of the class to check if the entity is an instance of.
   * @return <code>true</code> if the entity is an instance of the given class,
   *         <code>false</code> otherwise.
   */
  public boolean isInstanceOf(String classString) {
    return this.classes.contains(classString);
  }

  /**
   * Gets the abstractness count of the entity.
   * 
   * @return The abstractness count of the entity.
   */
  public int getAbstractnessCount() {
    return abstractnessCount;
  }

  /**
   * Sets the abstractness count of the entity.
   * 
   * @param abstractnessCount
   *          The abstractness count of the entity.
   */
  public void setAbstractnessCount(int abstractnessCount) {
    this.abstractnessCount = abstractnessCount;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof BroccoliEntityInfo) {
      return this.broccoliEntityString.equals(((BroccoliEntityInfo) obj)
          .getBroccoliEntityString());
    }
    return false;
  }

  @Override
  public int hashCode() {
    return this.broccoliEntityString.hashCode();
  }
}
