package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import broccoli.utility.EntityNameNormalizer;

/**
 * A map that specifies the entities that are supported by Broccoli.
 * 
 * @author Florian Bäurle
 */
public class BroccoliEntityMap {

  /**
   * A map that stores the possible entity names and their corresponding
   * Broccoli information.
   */
  private Map<String, BroccoliEntity> broccoliEntityMap;

  /**
   * A number format for the progress percentage.
   */
  private NumberFormat percentFormat = NumberFormat.getPercentInstance();
  
  
  /**
   * Maximum number of warnings to print.
   */
  private static final int MAX_NOF_WARNINGS = 15;


  /**
   * Creates a new {@link BroccoliEntityMap} from the provided files.
   * 
   * @param ontologyEntityListFile
   *          The filename of the ontology entity list to read.
   * @param redirectGroupsFile
   *          The filename of the redirect groups to read.
   * @param abstractnessCountsFile
   *          The filename of the abstractness counts file to read.
   * @throws IOException
   *           If an I/O error occurs while reading one of the input files.
   * @throws ParseException
   *           If the content of a provided input file is invalid.
   */
  public BroccoliEntityMap(String ontologyEntityListFile,
      String redirectGroupsFile, String abstractnessCountsFile,
      boolean treatAsFreebaseEntities, String freebaseMIdToWikipediaFile)
    throws IOException, ParseException {

    // configure the number format for the progress percentage
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);


    FreebaseMIdToWikipediaMap freebaseMIdToWikipediaMap = null;
    if (treatAsFreebaseEntities) {
      if (freebaseMIdToWikipediaFile == null) {
        throw new IllegalArgumentException(
            "The freebase mId to wikipedia mapping file must be set when the"
                + " entities should be treated as freebase entities!");
      }
      freebaseMIdToWikipediaMap =
          new FreebaseMIdToWikipediaMap(freebaseMIdToWikipediaFile);
    }

    System.out.println("Creating the Broccoli entity list ...");
    this.broccoliEntityMap = new HashMap<String, BroccoliEntity>();
    
    processOntologyEntityList(ontologyEntityListFile, 
        freebaseMIdToWikipediaMap);

    // second: read the redirect map and add additional entries for valid
    // redirects
    // NEW: May,7th 2012 (buchholb):
    // Use redirect groups instead of a map with single point of truth
    // targets.
    processRedirectGroups(redirectGroupsFile);

    System.out.println("... finished creating the Broccoli entity list!");
  }
  
  /**
   * 
   * @param abstractnessCountsFile
   * @throws IOException
   * @throws ParseException
   */
  private void processAbstractnessCounts(String abstractnessCountsFile)
    throws IOException, ParseException {
    String line;
    long startTime;
    long lastTimeDif;
    int lineCount;
    long totalFileBytes;
    long readFileBytes = 0;
    int nofWarningsWritten = 0;

    System.out.println("\tReading the abstractness counts file:");

    File abstractsFile = new File(abstractnessCountsFile);
    FileInputStream abstractsStream = new FileInputStream(abstractsFile);
    InputStreamReader abstractsStreamReader =
        new InputStreamReader(abstractsStream, "UTF-8");
    BufferedReader abstractsReader = new BufferedReader(abstractsStreamReader);
    startTime = System.currentTimeMillis();
    lineCount = 0;
    while ((line = abstractsReader.readLine()) != null) {
      ++lineCount;

      int indexOfTab = line.indexOf('\t');
      int abstractnessCount;
      try {
        abstractnessCount = Integer.parseInt(line.substring(0, indexOfTab));
      } catch (NumberFormatException e) {
        throw new ParseException(
            "The provided abstractness counts file contains an invalid number!",
            lineCount);
      }
      String broccoliEntityString = line.substring(indexOfTab + 1);
      if ((abstractnessCount < 0) || broccoliEntityString.isEmpty()) {
        throw new ParseException(
            "The provided abstractness counts file has invalid content!",
            lineCount);
      }

      int lastIndexofColon = broccoliEntityString.lastIndexOf(':');
      // make sure that the entity name is normalized, even though it normally
      // must be already
      String normalizedEntityName =
          EntityNameNormalizer.normalize(broccoliEntityString
              .substring(lastIndexofColon + 1));

      // set the abstractness count of the entity in the map in its entity info
      BroccoliEntity entityInfo =
          this.broccoliEntityMap.get(normalizedEntityName);
      if (entityInfo != null) {
        if (entityInfo.getAbstractnessCount() > 0) {
          System.out
              .println("WARNING: The provided abstractness counts file had a "
                  + "duplicate entry for '" + normalizedEntityName
                  + "'! The previous entry was overwritten!");
        }
        entityInfo.setAbstractnessCount(abstractnessCount);
      } else {
        System.out
            .println("WARNING: The provided abstractness counts file had an "
                + "entry for '" + normalizedEntityName
                + "' which was not contained in the known entities!");
      }
    }
    abstractsReader.close();
    
    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
         + (System.currentTimeMillis() - startTime) + "ms!");

  }

  
  /**
   * 
   * @param ontologyEntityListFile
   * @param freebaseMIdToWikipediaMap
   * @throws IOException
   * @throws ParseException
   */
  private void processOntologyEntityList(String ontologyEntityListFile,
    FreebaseMIdToWikipediaMap freebaseMIdToWikipediaMap) throws IOException,
    ParseException {
    // define helper variables for temp values and measurements
    String line;
    long startTime;
    long lastTimeDif;
    int lineCount;
    long totalFileBytes;
    long readFileBytes = 0;
    int nofWarningsWritten = 0;

    // first: read all possible entities and their classes from the ontology
    // entity list file

    System.out.println("\tReading the ontology entity list file:");
    
    // additional hash map that is used to ensure that the same string
    // references are used for equal classes
    ConcurrentMap<String, String> tempClasses =
        new ConcurrentHashMap<String, String>(16, 0.75f, 1);

    File listFile = new File(ontologyEntityListFile);
    FileInputStream listStream = new FileInputStream(listFile);
    InputStreamReader listStreamReader =
        new InputStreamReader(listStream, "UTF-8");
    BufferedReader listReader = new BufferedReader(listStreamReader);
    startTime = System.currentTimeMillis();
    lastTimeDif = 0;
    lineCount = 0;
    totalFileBytes = listFile.length();
    while ((line = listReader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 500000 == 0) {
        long currentTimeDif = System.currentTimeMillis() - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + this.percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      int indexOfTab = line.indexOf('\t');
      String broccoliEntityString = new String(line.substring(0, indexOfTab));
      String classesString = line.substring(indexOfTab + 1);
      if (broccoliEntityString.isEmpty() || classesString.isEmpty()) {
        listReader.close();
        throw new ParseException(
            "The provided ontology entity list file has invalid content!",
            lineCount);
      }

      Set<String> classesSet = new HashSet<String>();
      int nextIndexOfComma = classesString.indexOf(',');
      while (nextIndexOfComma >= 0) {
        String classString =
            new String(classesString.substring(0, nextIndexOfComma));
        if (!classString.isEmpty()) {
          // make sure to use the same string references for equal classes to
          // reduce the amount of needed memory
          classString = tempClasses.putIfAbsent(classString, classString);

          classesSet.add(classString);
        }

        // prepare for the next loop
        classesString = classesString.substring(nextIndexOfComma + 1);
        nextIndexOfComma = classesString.indexOf(',');
      }

      // create the broccoli entity info object
      BroccoliEntity broccoliEntityInfo =
          new BroccoliEntity(broccoliEntityString, classesSet);

   // get the normal entity name
      int lastIndexofColon = broccoliEntityString.lastIndexOf(':');
      // make sure that the entity name is normalized, even though it normally
      // must be already
      String normalizedEntityName =
          EntityNameNormalizer.normalize(broccoliEntityString
              .substring(lastIndexofColon + 1));

      // // --> HACK:
      // if (normalizedEntityName.endsWith(")")
      // && (normalizedEntityName.lastIndexOf("_(") > 0)) {
      // normalizedEntityName =
      // normalizedEntityName.substring(0,
      // normalizedEntityName.lastIndexOf("_("));
      // }
      // // NOTE: this is only useful if duplicates do not overwrite old entries
      // // but are added as a kind of "redirect" similar to the old redirect
      // // map?
      // // <-- HACK
      // --> HACK: try to replace the freebase entity names by their
      //     corresponding wikipedia article names, if not possible just remove
      //     the mIds for the recognition
      // NOTE: thus generated duplicates will currently overwrite previous
      // entries!
      ArrayList<String> normalizedEntityNames = new ArrayList<String>();
      normalizedEntityNames.add(normalizedEntityName);

      if (freebaseMIdToWikipediaMap != null) {
        if (normalizedEntityName.endsWith(")")) {
          int lastOpenIndex = normalizedEntityName.lastIndexOf("_(");
          int lastCloseIndex = normalizedEntityName.lastIndexOf(")");
          if (lastOpenIndex > 0) {
            String bracketAnnotation =
                normalizedEntityName.substring(lastOpenIndex + 2,
                    lastCloseIndex);
            // try to get the corresponding wikipedia article names and add
            // them as "redirects"
            ArrayList<String> wikipediaArticles =
                freebaseMIdToWikipediaMap
                    .getWikipediaArticleList(bracketAnnotation);
            if (wikipediaArticles != null) {
              for (String wikiArticle : wikipediaArticles) {
                normalizedEntityNames.add(EntityNameNormalizer
                    .normalize(wikiArticle));
              }
            } else {
              // if there were no corresponding wikipedia articles then just
              // remove the bracket and add that as "redirect"
              normalizedEntityNames.add(normalizedEntityName.substring(0,
                  lastOpenIndex));
            }
          }
        }
      }
      // <-- HACK

      for (String entityName : normalizedEntityNames) {
        BroccoliEntity temp =
            this.broccoliEntityMap.put(/* normalizedEntityName */entityName,
                broccoliEntityInfo);
        if (temp != null) {
          if (nofWarningsWritten < MAX_NOF_WARNINGS) {
            // TODO: make a better error handling here
            // throw new ParseException(
            // "The provided ontology entity list file contains a duplicate "
            // + "entry for the entity '" + broccoliEntityString + "'!",
            // lineCount);
            // System.out.println("WARNING: The provided ontology entity list "
            // + "file had a duplicate entry for '" + normalizedEntityName
            // + "'! The previous entry was overwritten!");
            System.out.println("WARNING: The provided ontology entity list "
                + "file had a duplicate entry for '"
                + /* normalizedEntityName */entityName
                + "'! The previous entry '" + temp.getBroccoliEntityName()
                + "' was overwritten by '"
                + broccoliEntityInfo.getBroccoliEntityName() + "'!");
            ++nofWarningsWritten;
          } else {
            if (nofWarningsWritten == MAX_NOF_WARNINGS) {
              System.out.println("WARNING: There are more duplicate entries, "
                  + "suppressing warnings...");
              ++nofWarningsWritten;
            }
          }
        }
      }
    }
    listReader.close();
    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");

  }


  /**
   * @param redirectGroupsFile
   * @throws IOException
   */
  private void processRedirectGroups(String redirectGroupsFile)
    throws IOException {
    if (redirectGroupsFile == null) {
      System.out.println("\tNo redirect groups file provided.");
      return;
    }
    System.out.println("\tReading the redirect groups file:");

    File mapFile = new File(redirectGroupsFile);
    FileInputStream mapStream = new FileInputStream(mapFile);
    InputStreamReader mapStreamReader =
        new InputStreamReader(mapStream, "UTF-8");
    BufferedReader reader = new BufferedReader(mapStreamReader);

    int nofIgnoredGroups = 0;
    int nofGroupsTotal = 0;
    long startTime = System.currentTimeMillis();
    long lastTimeDif = 0;

    long totalFileBytes = mapFile.length();
    long readFileBytes = 0;

    for (String line = reader.readLine(); line != null; line =
        reader.readLine()) {
      ++nofGroupsTotal;

      readFileBytes += line.getBytes("UTF-8").length;

      if (nofGroupsTotal % 500000 == 0) {
        long currentTimeDif = System.currentTimeMillis() - startTime;
        System.out.println("\tRead "
            + nofGroupsTotal
            + " groups in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + this.percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }
      // Tokenize the line and get all items in this redirect groups.
      StringTokenizer st = new StringTokenizer(line, " ");
      // Count the number of targets that are matched in the
      // broccoli entity map constructed so far.
      BroccoliEntity lastInfo = null;
      boolean useRedirects = true;
      while (st.hasMoreTokens()) {
        BroccoliEntity thisInfo =
            this.broccoliEntityMap.get(st.nextToken());
        if (thisInfo != null) {
          if (lastInfo != null && lastInfo != thisInfo) {
            useRedirects = false;
            if (lastInfo != null) {
              ++nofIgnoredGroups;
            }
            break;
          }
          lastInfo = thisInfo;
        }
      }
      if (useRedirects && lastInfo != null) {
        // If the number is exactly 1, add all keys to the broccoli entity map.
        st = new StringTokenizer(line, " ");
        while (st.hasMoreTokens()) {
          this.broccoliEntityMap.put(st.nextToken(), lastInfo);
        }
      }
    }
    reader.close();
    
    System.out.println("Done reading the redirect-groups file.");
    System.out.println("Had to ignore " + nofIgnoredGroups
        + " groups because they could be associated with multiple entities. "
        + "(out of " + nofGroupsTotal
        + " groups that were processed in total)");
  }

  /**
   * Checks if the given entity is contained.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @return <code>true</code> if the entity is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsEntity(String entityName) {
    return this.broccoliEntityMap.containsKey(EntityNameNormalizer
        .normalize(entityName));
  }

  /**
   * Gets the {@link BroccoliEntity} of a contained entity.
   * 
   * @param entityName
   *          The name of the entity to get the Broccoli entity information.
   * @return The Broccoli entity information of the given entity or
   *         <code>null</code> if the entity is not contained.
   */
  public BroccoliEntity getBroccoliEntityInfo(String entityName) {
    return this.broccoliEntityMap.get(EntityNameNormalizer
        .normalize(entityName));
  }
}
