package broccoli.entityrecognizer.data;

import java.util.List;

import broccoli.entityrecognizer.annotations.EntityAnnotation;

/**
 * Container object for the results of an entity recognition run.
 * 
 * @author Florian Bäurle
 */
public class EntityRecognitionResult {

  /**
   * Stores the broccoli string of the document entity if there is one, or
   * <code>null</code> otherwise.
   */
  private String documentEntityBroccoliString;
  /**
   * Stores a list of the recognized entities in the document.
   */
  private List<EntityAnnotation> recognizedEntities;

  /**
   * Creates a new {@link EntityRecognitionResult}.
   */
  public EntityRecognitionResult() {
  }

  /**
   * Gets the broccoli string of the document entity.
   * 
   * @return The broccoli string of the document entity if there is one, or
   *         <code>null</code> otherwise.
   */
  public String getDocumentEntityBroccoliString() {
    return this.documentEntityBroccoliString;
  }

  /**
   * Sets the broccoli string of the document entity.
   * 
   * @param documentEntityBroccoliString
   *          The broccoli string of the document entity if there is one, or
   *          <code>null</code> otherwise.
   */
  public void setDocumentEntityBroccoliString(
    String documentEntityBroccoliString) {
    this.documentEntityBroccoliString = documentEntityBroccoliString;
  }

  /**
   * Gets the list of recognized entities in the document.
   * 
   * @return The list of recognized entities in the document.
   */
  public List<EntityAnnotation> getRecognizedEntities() {
    return this.recognizedEntities;
  }

  /**
   * Sets the list of recognized entities in the document.
   * 
   * @param recognizedEntities
   *          The list of recognized entities in the document.
   */
  public void setRecognizedEntities(List<EntityAnnotation> recognizedEntities) {
    this.recognizedEntities = recognizedEntities;
  }
}
