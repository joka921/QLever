package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import broccoli.utility.EntityNameNormalizer;

/**
 * A repository of all entities supported by the entity recognition. The central
 * container is a map from (unique) entity name to the corresponding
 * BroccoliEntity object.
 * 
 * 
 * @author Elmar Haussmann
 */
public class EntityRepository {

  /**
   * A map from entity name to corresponding entity.
   */
  private Map<String, BroccoliEntity> entityNameMap;

  /**
   * A set of all entities.
   */
  private Set<BroccoliEntity> entities;

  /**
   * A set of all entity aliases that are unique over all existing aliases.
   */
  private Set<String> uniqueAliases;

  /**
   * Get the set of unique aliases.
   * 
   * @return
   */
  public Set<String> getUniqueAliases() {
    return uniqueAliases;
  }

  /**
   * Set the set of unique aliases.
   * 
   * @param uniqueAliases
   */
  public void setUniqueAliases(Set<String> uniqueAliases) {
    this.uniqueAliases = uniqueAliases;
  }

  /**
   * Is the provided alias unique within all entity aliases.
   * 
   * @param alias
   * @return
   */
  public boolean isUniqueAlias(String alias) {
    return this.uniqueAliases.contains(alias);
  }

  /**
   * 
   * @return
   */
  public Set<BroccoliEntity> getEntities() {
    return entities;
  }

  /**
   * 
   * @param entities
   */
  public void setEntities(Set<BroccoliEntity> entities) {
    this.entities = entities;
  }

  /**
   * A map from word to its score, indicating how concrete the word is.
   */
  private HashMap<String, Double> wordConcretenessScores = 
      new HashMap<String, Double>();

  /**
   * A number format for the progress percentage.
   */
  private NumberFormat percentFormat = NumberFormat.getPercentInstance();

  /**
   * Maximum number of warnings to print.
   */
  private static final int MAX_NOF_WARNINGS = 15;

  /**
   * Creates a new {@link EntityRepository} from the provided files.
   * 
   * @param wordConcretenessFile
   * 
   */
  public EntityRepository(String broccoliEntitiesFile,
      String wordConcretenessFile) throws IOException, ParseException {

    // configure the number format for the progress percentage
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);

    this.entityNameMap = new HashMap<String, BroccoliEntity>(30000000, 0.75f);
    this.entities = new HashSet<BroccoliEntity>(30000000, 0.75f);
    this.uniqueAliases = new HashSet<String>(10000000, 0.75f);

    readWordConcreteness(wordConcretenessFile);

    readBroccoliEntities(broccoliEntitiesFile);


    System.out.println("... finished creating the Broccoli entity list!");
  }

  /**
   * Read word concreteness file.
   * @param wordConcretenessFile
   * @throws IOException
   * @throws ParseException
   */
  private void readWordConcreteness(String wordConcretenessFile)
    throws IOException, ParseException {
    // TODO Auto-generated method stub
    System.out.println("Reading word concreteness from " + wordConcretenessFile
        + ".");
    File abstractsFile =  new File(wordConcretenessFile);
    FileInputStream abstractsStream = new FileInputStream(abstractsFile);
    InputStreamReader abstractsStreamReader = new InputStreamReader(
        abstractsStream, "UTF-8");
    BufferedReader abstractsReader = new BufferedReader(abstractsStreamReader);
    int lineCount = 0;
    String line;
    while ((line = abstractsReader.readLine()) != null) {
      ++lineCount;
      String[] columns = line.split("\t");
      if (columns.length != 2) {
        throw new ParseException(
            "The provided word concreteness file contains "
                + "an invalid number of columns!", lineCount);
      }
      this.wordConcretenessScores.put(columns[0], Double.valueOf(columns[1]));
    }
    abstractsReader.close();
    System.out.println("Done (" + this.wordConcretenessScores.size() 
        + " elements).");
  }

  /**
   * 
   * @param abstractnessCountsFile
   * @throws IOException
   * @throws ParseException
   */
  private void readbstractnessCounts(String abstractnessCountsFile)
    throws IOException, ParseException {
    String line;
    long startTime;
    int lineCount;
    int nofWarningsWritten = 0;

    System.out.println("\tReading the abstractness counts file:");

    File abstractsFile = new File(abstractnessCountsFile);
    FileInputStream abstractsStream = new FileInputStream(abstractsFile);
    InputStreamReader abstractsStreamReader = new InputStreamReader(
        abstractsStream, "UTF-8");
    BufferedReader abstractsReader = new BufferedReader(abstractsStreamReader);
    startTime = System.currentTimeMillis();
    lineCount = 0;
    while ((line = abstractsReader.readLine()) != null) {
      ++lineCount;

      int indexOfTab = line.indexOf('\t');
      int abstractnessCount;
      try {
        abstractnessCount = Integer.parseInt(line.substring(0, indexOfTab));
      } catch (NumberFormatException e) {
        throw new ParseException(
            "The provided abstractness counts file contains "
                + "an invalid number!", lineCount);
      }
      String broccoliEntityString = line.substring(indexOfTab + 1);
      if ((abstractnessCount < 0) || broccoliEntityString.isEmpty()) {
        throw new ParseException(
            "The provided abstractness counts file has invalid content!",
            lineCount);
      }

      int lastIndexofColon = broccoliEntityString.lastIndexOf(':');
      // make sure that the entity name is normalized, even though it normally
      // must be already
      String normalizedEntityName = EntityNameNormalizer
          .normalize(broccoliEntityString.substring(lastIndexofColon + 1));

      // set the abstractness count of the entity in the map in its entity info
      BroccoliEntity entity = this.entityNameMap.get(normalizedEntityName);
      if (entity != null) {
        if (entity.getAbstractnessCount() > 0
            && nofWarningsWritten < MAX_NOF_WARNINGS) {
          System.out
              .println("WARNING: The provided abstractness counts file had a "
                  + "duplicate entry for '" + normalizedEntityName
                  + "'! The previous number was overwritten!");
          nofWarningsWritten++;
        }
        entity.setAbstractnessCount(abstractnessCount);
      } else if (nofWarningsWritten < MAX_NOF_WARNINGS) {
        System.out
            .println("WARNING: The provided abstractness counts file had an "
                + "entry for '" + normalizedEntityName
                + "' which was not contained in the known entities!");
        nofWarningsWritten++;
      } else if (nofWarningsWritten == MAX_NOF_WARNINGS) {
        System.out.println("WARNING: Suppressing additional warnings...");
        nofWarningsWritten++;
      }
    }
    abstractsReader.close();

    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");
  }

  /**
   * 
   * @param ontologyEntityListFile
   * @throws IOException
   * @throws ParseException
   */
  private void readBroccoliEntities(String ontologyEntityListFile)
    throws IOException, ParseException {
    Set<String> duplicateNames = new HashSet<String>(50000000, 0.75f);
    // define helper variables for temp values and measurements
    String line;
    long startTime;
    long lastTimeDif;
    int lineCount;
    long totalFileBytes;
    long readFileBytes = 0;
    int nofWarningsWritten = 0;

    System.out.println("\tReading the ontology entity file from: "
        + ontologyEntityListFile);

    File listFile = new File(ontologyEntityListFile);
    FileInputStream listStream = new FileInputStream(listFile);
    InputStreamReader listStreamReader = new InputStreamReader(listStream,
        "UTF-8");
    BufferedReader listReader = new BufferedReader(listStreamReader);
    startTime = System.currentTimeMillis();
    lastTimeDif = 0;
    lineCount = 0;
    totalFileBytes = listFile.length();

    while ((line = listReader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 500000 == 0) {
        long currentTimeDif = System.currentTimeMillis() - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + this.percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      // File is tab separated: entityname, classes, aliasnames.
      String[] columns = line.split("\t");

      // Empty entityname or classes is not allowed.
      if (columns.length < 4 || columns[0].isEmpty() || columns[1].isEmpty()) {
        listReader.close();
        throw new ParseException(
            "The provided ontology entity list file has invalid content!",
            lineCount);
      }
      String broccoliEntityName = columns[0];
      String classesString = columns[1];
      int score = Integer.valueOf(columns[2]);
      int abstractnessCount = Integer.valueOf(columns[3]);

      // The classes are comma-separated. Split them.
      Set<String> classesSet = new HashSet<String>();
      if (classesString.contains(",")) {
        String[] classes = classesString.split(",");
        for (String classString : classes) {
          // make sure to use the same string references for equal classes to
          // reduce the amount of needed memory
          if (!classString.isEmpty()) {
            classesSet.add(classString.intern());
          }
        }
      } else {
        classesSet.add(classesString.intern());
      }

      BroccoliEntity temp = this.entityNameMap.get(broccoliEntityName);
      // Check for duplicate entity.
      if (temp == null) {
        // create the broccoli entity info object
        BroccoliEntity entity = new BroccoliEntity(broccoliEntityName,
            classesSet, score, abstractnessCount);
        // Add the entity's alias names.
        // The remaining columns are the aliases.
        for (int c = 4; c < columns.length; ++c) {
          String aliasName = columns[c];
          if (!aliasName.isEmpty()) {
            entity.addAlias(aliasName);
            if (!duplicateNames.contains(aliasName)) {
              if (uniqueAliases.contains(aliasName)) {
                uniqueAliases.remove(aliasName);
                duplicateNames.add(aliasName);
              } else {
                uniqueAliases.add(aliasName);
              }
            }
          }
        }
        this.entityNameMap.put(broccoliEntityName, entity);
        this.entities.add(entity);
      } else {
        if (nofWarningsWritten < MAX_NOF_WARNINGS) {
          System.out.println("WARNING: The provided ontology entity "
              + "file had a duplicate entry for '" + broccoliEntityName
              + "'! Ignoring duplicate entry.");
          ++nofWarningsWritten;
        } else {
          if (nofWarningsWritten == MAX_NOF_WARNINGS) {
            System.out.println("WARNING: There are more duplicate entries, "
                + "suppressing warnings...");
            ++nofWarningsWritten;
          }
        }
      }

    }
    listReader.close();
    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");
  }

  /**
   * Checks if the given entity is contained.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @return <code>true</code> if the entity is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsEntity(String entityName) {
    return this.entityNameMap.containsKey(EntityNameNormalizer
        .normalize(entityName));
  }

  /**
   * Gets the entity for a surface text, but does not normalize the surface
   * text.
   * 
   */
  public BroccoliEntity getBroccoliEntityExact(String surfaceText) {
    return this.entityNameMap.get(surfaceText);
  }

  /**
   * Gets the entity for a surface text.
   * 
   */
  public BroccoliEntity getBroccoliEntity(String surfaceText) {
    return this.entityNameMap.get(EntityNameNormalizer.normalize(surfaceText));
  }
  
  /**
   * Return the concretenss score if word found 
   * or 1.0 if not found. 
   * @param word
   * @return
   */
  public double getWordConcreteness(String word) {
    if (this.wordConcretenessScores.containsKey(word)) {
      return this.wordConcretenessScores.get(word);
    } else {
      return 1.0;
    }
  }
  
}
