package broccoli.entityrecognizer.data;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import broccoli.utility.EntityNameNormalizer;

/**
 * A map from text surface forms of entities to the corresponding entity.
 * Currently each text surface form has to be unique.
 * 
 * Anaphora/Co-reference is not handled via this map but directly via the entity
 * recognizer.
 * 
 * @author Elmar Haussmann
 */
public class EntitySurfaceMap {

  /**
   * A map from text surface string to corresponding entity.
   */
  private Map<String, BroccoliEntity> surfaceEntityMap;

  /**
   * Creates a new {@link EntitySurfaceMap} from the provided files.
   * 
   */
  public EntitySurfaceMap(EntityRepository er) {
    System.out.println("Generating the entity surface for all classes.");
    this.surfaceEntityMap = new HashMap<String, BroccoliEntity>(30000000,
        0.75f);
    buildSurfaceMap(er, null, false);
    System.out.println("... finished!");
  }

  /**
   * Creates a new {@link EntitySurfaceMap} from the provided files.
   * 
   */
  public EntitySurfaceMap(EntityRepository er, Set<String> classes,
      boolean onlyUnique) {
    this.surfaceEntityMap = new HashMap<String, BroccoliEntity>(5000000, 0.75f);
    System.out.println("Generating the entity surface for selected classes.");
    buildSurfaceMap(er, classes, onlyUnique);
    System.out.println("... finished (" + this.surfaceEntityMap.size()
        + " elements)!");
  }

  /**
   * 
   * @param a
   * @param b
   * @return
   */
  public static <X> boolean intersectEmpty(Set<X> a, Set<X> b) {
    boolean intersectEmpty = true;
    for (X elementA : a) {
      if (b.contains(elementA)) {
        intersectEmpty = false;
        break;
      }
    }
    return intersectEmpty;
  }

  /**
   * 
   * @param er
   * @param classes
   */
  private void buildSurfaceMap(EntityRepository er, Set<String> classes,
    boolean onlyUnique) {
    for (BroccoliEntity entity : er.getEntities()) {
      // Check if the entity is in one of the desired classes.
      if (classes != null && classes.size() > 0
          && intersectEmpty(classes, entity.getClasses())) {
        continue;
      }
      // Add entity with alias names.
      for (String alias : entity.getAliases()) {
        if (onlyUnique) {
          // Only add unique aliases.
          if (er.isUniqueAlias(alias)) {
            this.surfaceEntityMap.put(alias, entity);
          }
        } else {
          this.surfaceEntityMap.put(alias, entity);
        }
      }
    }
    // TODO Auto-generated method stub
  }

  /**
   * Checks if the given entity is contained.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @return <code>true</code> if the entity is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsEntity(String entityName) {
    return this.surfaceEntityMap.containsKey(EntityNameNormalizer
        .normalize(entityName));
  }

  /**
   * Gets the entity for a surface text, but does not normalize the surface
   * text.
   * 
   */
  public BroccoliEntity getBroccoliEntityExact(String surfaceText) {
    return this.surfaceEntityMap.get(surfaceText);
  }

  /**
   * 
   * @return
   */
  public int size() {
    return this.surfaceEntityMap.size();
  }

  /**
   * Gets the entity for a surface text.
   * 
   */
  public BroccoliEntity getBroccoliEntity(String surfaceText) {
    return this.surfaceEntityMap.get(EntityNameNormalizer
        .normalize(surfaceText));
  }
}
