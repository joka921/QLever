package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 
 * @author haussmae
 *
 */
public class FreebaseMIdToWikipediaMap {
  
  /**
   * 
   */
  private HashMap<String, ArrayList<String>> map;

  /**
   * 
   */
  private NumberFormat percentFormat = NumberFormat.getPercentInstance();

  /**
   * 
   * @param freebaseMIdToWikipediaFile
   * @throws IOException
   * @throws ParseException
   */
  public FreebaseMIdToWikipediaMap(String freebaseMIdToWikipediaFile)
    throws IOException, ParseException {
    if (freebaseMIdToWikipediaFile == null) {
      throw new IllegalArgumentException(
          "The freebase mId to wikipedia mapping file must not be null!");
    }

    this.map = new HashMap<String, ArrayList<String>>();

    // configure the number format for the progress percentage
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);

    // define helper variables for temp values and measurements
    String line;
    long startTime;
    long lastTimeDif;
    int lineCount;
    long totalFileBytes;
    long readFileBytes = 0;

    System.out
        .println("\tReading the freebase mId to wikipedia mapping file:");

    File mIdWikiMapFile = new File(freebaseMIdToWikipediaFile);
    BufferedReader mIdWikiMapReader =
        new BufferedReader(new InputStreamReader(new FileInputStream(
            mIdWikiMapFile), "UTF-8"));
    startTime = System.currentTimeMillis();
    lastTimeDif = 0;
    lineCount = 0;
    totalFileBytes = mIdWikiMapFile.length();
    while ((line = mIdWikiMapReader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 500000 == 0) {
        long currentTimeDif = System.currentTimeMillis() - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + this.percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      int indexOfTab = line.indexOf('\t');
      String freebaseMId = new String(line.substring(0, indexOfTab));
      String wikipediaArticle = new String(line.substring(indexOfTab + 1));
      if (freebaseMId.isEmpty() || wikipediaArticle.isEmpty()) {
        mIdWikiMapReader.close();
        throw new ParseException(
            "The provided freebase mId to wikipedia mapping file has invalid "
                + "content!", lineCount);
      }
      // String temp = this.map.put(freebaseMId, wikipediaArticle);
      // if (temp != null) {
      // System.out
      // .println("WARNING: The provided freebase mId to wikipedia mapping "
      // + "file had a duplicate entry for '"
      // + freebaseMId
      // + "'! The previous entry '"
      // + temp
      // + "' was overwritten by '"
      // + wikipediaArticle + "'!");
      // }
      ArrayList<String> wikiArticleList = this.map.get(freebaseMId);
      if (wikiArticleList == null) {
        wikiArticleList = new ArrayList<String>();
        this.map.put(freebaseMId, wikiArticleList);
      }
      wikiArticleList.add(wikipediaArticle);
    }
    mIdWikiMapReader.close();

    System.out.println("\tReading finished!");
    System.out.println("\tRead " + lineCount + " lines in "
        + (System.currentTimeMillis() - startTime) + "ms!");
  }

  /**
   * 
   * @param mId
   * @return
   */
  public boolean containsMId(String mId) {
    if (!mId.startsWith("ns:e.")) {
      mId = "ns:e." + mId;
    }
    return this.map.containsKey(mId);
  }

  /**
   * 
   * @param mId
   * @return
   */
  public ArrayList<String> getWikipediaArticleList(String mId) {
    if (!mId.startsWith("ns:e.")) {
      mId = "ns:e." + mId;
    }
    return this.map.get(mId);
  }
}
