// Copyright 2014 Philipp Bausch <bauschp@informatik.uni-freiburg.de>

package broccoli.entityrecognizer.data;

import java.util.Map;
import java.util.Set;
import broccoli.utility.EntityNameNormalizer;

/**
 * A Surface-Map, that supports any Map-like structure.
 * Maps that implement PrefixCheckable provide more functionalities.
 */
public class GeneralSurfaceMap {

  /**
   * A interface that can be implemented by map implementations to support
   * prefix checks.
   */
  public interface PrefixCheckable {
    /**
     * Returns wheter or not s is prefix of more elements.
     */
    boolean isPrefix(String s);
  }
  /**
   * An exception that is thrown if the map doesnt support this operation.
   */
  public class UnsupportedDataStructureException extends Exception {
    /**
     * serializable id.
     */
    private static final long serialVersionUID = 1115550l;
    /**
     * The constructor with a given error message.
     */
    public UnsupportedDataStructureException(String message) {
      super(message);
    }
  }
  /**
   * A map from text surface string to corresponding entity.
   */
  private Map<String, BroccoliEntity> surfaceEntityMap;
  /**
   * A enumeration that tracks the state of supportiveness.
   */
  private enum SupportState {
    /**
     * UNKNOWN.
     */
    UNKNOWN,
    /**
     * SUPPORTED.
     */
    SUPPORTED,
    /**
     * UNSUPPORTED.
     */
    NOT_SUPPORTED
  }
  /**
   * Current state of prefixSupport.
   */
  private SupportState supportsPrefix;

  /**
   * 
   * 
   */
  public GeneralSurfaceMap(EntityRepository er,
      Map<String, BroccoliEntity> map) {
    System.out.println("Generating the entity surface for all classes.");
    supportsPrefix = SupportState.UNKNOWN;
    this.surfaceEntityMap = map;
    buildSurfaceMap(er, null, false);
    System.out.println("... finished!");
  }

  /**
   * 
   * 
   */
  public GeneralSurfaceMap(EntityRepository er, Set<String> classes,
      boolean onlyUnique, Map<String, BroccoliEntity> map) {
    supportsPrefix = SupportState.UNKNOWN;
    this.surfaceEntityMap = map;
    System.out.println("Generating the entity surface for selected classes.");
    buildSurfaceMap(er, classes, onlyUnique);
    System.out.println("... finished (" + this.surfaceEntityMap.size()
        + " elements)!");
  }
  
  /**
   * The view of the map for prefixes.
   */
  private PrefixCheckable prefixCheckableMapView;
  /**
   * Returns if the string is a prefix of more entries.
   * Throws an Exception if unsupported.
   */
  public boolean isPrefixOfEntities(String s)
    throws UnsupportedDataStructureException {
    // Check if map supports prefix. (de morgan for speed up).
    if (!(supportsPrefix != SupportState.NOT_SUPPORTED
        && supportsPrefix != SupportState.UNKNOWN)) {
      // If state is unknown. Find out if the map supports it.
      if (supportsPrefix == SupportState.UNKNOWN) {
        // Is called once.
        if (surfaceEntityMap instanceof PrefixCheckable) {
          supportsPrefix = SupportState.SUPPORTED;
          prefixCheckableMapView = (PrefixCheckable) surfaceEntityMap;
          return prefixCheckableMapView.isPrefix(s);
        }
        supportsPrefix = SupportState.NOT_SUPPORTED;
      }
      throw new UnsupportedDataStructureException(
        surfaceEntityMap.getClass().getName()
        + " doesn't support this operation");
    }
    return prefixCheckableMapView.isPrefix(s);
  }

  /**
   * 
   * @param er
   * @param classes
   */
  private void buildSurfaceMap(EntityRepository er, Set<String> classes,
    boolean onlyUnique) {
    for (BroccoliEntity entity : er.getEntities()) {
      // Check if the entity is in one of the desired classes.
      if (classes != null && classes.size() > 0
          && intersectEmpty(classes, entity.getClasses())) {
        continue;
      }
      // Add entity with alias names.
      for (String alias : entity.getAliases()) {
        if (onlyUnique) {
          // Only add unique aliases.
          if (er.isUniqueAlias(alias)) {
            this.surfaceEntityMap.put(alias, entity);
          }
        } else {
          this.surfaceEntityMap.put(alias, entity);
        }
      }
    }
    // TODO Auto-generated method stub
  }

  /**
   * 
   * @param a
   * @param b
   * @return
   */
  public static <X> boolean intersectEmpty(Set<X> a, Set<X> b) {
    boolean intersectEmpty = true;
    for (X elementA : a) {
      if (b.contains(elementA)) {
        intersectEmpty = false;
        break;
      }
    }
    return intersectEmpty;
  }

  /**
   * Gets the entity for a surface text.
   * 
   */
  public BroccoliEntity getBroccoliEntity(String surfaceText) {
    return this.surfaceEntityMap.get(EntityNameNormalizer
        .normalize(surfaceText));
  }
}
