package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Provides access to an ontology entity list.
 * 
 * @author Florian Bäurle
 */
public class OntologyEntityList {

  /**
   * A map that stores the entity names and their corresponding Broccoli
   * information.
   */
  private Map<String, BroccoliEntity> ontologyEntityMap;

  /**
   * Creates a new {@link OntologyEntityList} from the given file.
   * 
   * @param filename
   *          The filename of the ontology entity list to read.
   * @throws IOException
   *           If an I/O error occurs while reading the ontology entity list
   *           file.
   * @throws ParseException
   *           If the content of the provided ontology entity list file is
   *           invalid.
   */
  public OntologyEntityList(String filename) throws IOException,
    ParseException {

    this.ontologyEntityMap = new HashMap<String, BroccoliEntity>();

    NumberFormat percentFormat = NumberFormat.getPercentInstance();
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);

    File listFile = new File(filename);
    FileInputStream stream = new FileInputStream(listFile);
    InputStreamReader streamReader = new InputStreamReader(stream, "UTF-8");
    BufferedReader reader = new BufferedReader(streamReader);

    // additional hash map that is used to ensure that the same string
    // references are used for equal classes
    ConcurrentMap<String, String> tempClasses =
        new ConcurrentHashMap<String, String>(16, 0.75f, 1);

    long startTime = System.currentTimeMillis();
    long lastTimeDif = 0;

    long totalFileBytes = listFile.length();
    long readFileBytes = 0;

    String line;
    int lineCount = 0;
    while ((line = reader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 100000 == 0) {
        long currentTime = System.currentTimeMillis();
        long currentTimeDif = currentTime - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms) ("
            + percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      int indexOfTab = line.indexOf('\t');
      String broccoliEntityString = new String(line.substring(0, indexOfTab));
      String classesString = line.substring(indexOfTab + 1);

      if (broccoliEntityString.isEmpty() || classesString.isEmpty()) {
        throw new ParseException(
            "The provided ontology entity list file has invalid content!",
            lineCount);
      }

      int lastIndexofColon = broccoliEntityString.lastIndexOf(':');
      String entityName = broccoliEntityString.substring(lastIndexofColon + 1);

      Set<String> classesSet = new HashSet<String>();
      int nextIndexOfComma = classesString.indexOf(',');
      while (nextIndexOfComma >= 0) {
        String classString =
            new String(classesString.substring(0, nextIndexOfComma));
        if (!classString.isEmpty()) {
          // make sure to use the same string references for equal classes to
          // reduce the amount of needed memory
          classString = tempClasses.putIfAbsent(classString, classString);

          classesSet.add(classString);
        }

        // prepare for the next loop
        classesString = classesString.substring(nextIndexOfComma + 1);
        nextIndexOfComma = classesString.indexOf(',');
      }

      // create the broccoli entity info object
      BroccoliEntity broccoliEntityInfo =
          new BroccoliEntity(broccoliEntityString, classesSet);

      if (this.ontologyEntityMap.put(entityName, broccoliEntityInfo) != null) {
        throw new ParseException(
            "The provided ontology entity list file contains a duplicate "
                + "entry for the entity '" + broccoliEntityString + "'!",
            lineCount);
      }
    }

    System.out.println("\tReading finished!");
    long currentTime = System.currentTimeMillis();
    System.out.println("\tRead " + lineCount + " lines in "
        + (currentTime - startTime) + "ms!");

    reader.close();
  }

  /**
   * Checks if the given entity is contained in this ontology entity list.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @return <code>true</code> if the entity is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsEntity(String entityName) {
    return this.ontologyEntityMap.containsKey(entityName);
  }

  /**
   * Gets the Broccoli string of a contained entity.
   * 
   * @param entityName
   *          The name of the entity to get the Broccoli string.
   * @return The Broccoli string of the given entity or <code>null</code> if the
   *         entity is not contained.
   */
  public String getBroccoliString(String entityName) {
    // TODO: remove the call to the 'used serializer' which is only needed to
    // create a smaller list for test purposes
    // OntologyEntityListUsedSerializer.getInstance().markEntityUsed(this,
    // entityName);

    BroccoliEntity broccoliEntityInfo =
        this.ontologyEntityMap.get(entityName);
    if (broccoliEntityInfo != null) {
      return broccoliEntityInfo.getBroccoliEntityName();
    } else {
      return null;
    }
  }

  /**
   * Gets a copy of the set of classes of which the given entity is an instance
   * of.
   * 
   * @param entityName
   *          The name of the entity to get the classes from.
   * @return A copy of the set of classes of the entiy or <code>null</code> if
   *         the entity is not contained.
   */
  public Set<String> getEntityClasses(String entityName) {
    BroccoliEntity broccoliEntityInfo =
        this.ontologyEntityMap.get(entityName);
    if (broccoliEntityInfo != null) {
      return new HashSet<String>(broccoliEntityInfo.getClasses());
    } else {
      return null;
    }
  }

  /**
   * Checks if a contained entity is an instance of a certain class.
   * 
   * @param entityName
   *          The name of the entity to check.
   * @param className
   *          The name of the class to check if the entity is an instance of.
   * @return <code>true</code> if the entity is an instance of the given class,
   *         <code>false</code> if the entity is not an instance of the given
   *         class or if the entity is not contained.
   */
  public boolean isEntityA(String entityName, String className) {
    BroccoliEntity broccoliEntityInfo =
        this.ontologyEntityMap.get(entityName);
    if (broccoliEntityInfo != null) {
      return broccoliEntityInfo.getClasses().contains(className);
    } else {
      return false;
    }
  }
}
