package broccoli.entityrecognizer.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Provides access to a redirect map.
 * 
 * @author Florian Bäurle
 */
public class RedirectMap {

  /**
   * A hash map that stores which article redirects to which article.
   */
  private Map<String, String> redirectMap;

  /**
   * Creates a new {@link RedirectMap} from the given file.
   * 
   * @param filename
   *          The filename of the redirect map to read.
   * @throws IOException
   *           If an I/O error occurs while reading the ontology entity list
   *           file.
   * @throws ParseException
   *           If the content of the provided redirect map file is invalid.
   */
  public RedirectMap(String filename) throws IOException, ParseException {
    // take a large initial capacity to reduce the number of potential
    // rehashings!
    this.redirectMap = new HashMap<String, String>(); // 30000000 10000000

    NumberFormat percentFormat = NumberFormat.getPercentInstance();
    percentFormat.setMinimumFractionDigits(2);
    percentFormat.setMaximumFractionDigits(2);

    File redirectFile = new File(filename);
    FileInputStream stream = new FileInputStream(redirectFile);
    InputStreamReader streamReader = new InputStreamReader(stream, "UTF-8");
    BufferedReader reader = new BufferedReader(streamReader);

    // additional hash map that is used to ensure that the same string
    // references are used for equal redirect names
    ConcurrentMap<String, String> tempRedirectNames =
        new ConcurrentHashMap<String, String>(16, 0.75f, 1); // (30000000,
                                                             // 0.75f, 1)
                                                             // (10000000,
                                                             // 0.75f, 1)

    long startTime = System.currentTimeMillis();
    long lastTimeDif = 0;

    long totalFileBytes = redirectFile.length();
    long readFileBytes = 0;

    String line;
    int lineCount = 0;
    while ((line = reader.readLine()) != null) {
      ++lineCount;

      readFileBytes += line.getBytes("UTF-8").length;

      if (lineCount % 1000000 == 0) {
        long currentTime = System.currentTimeMillis();
        long currentTimeDif = currentTime - startTime;
        System.out.println("\tRead "
            + lineCount
            + " lines in "
            + currentTimeDif
            + "ms! (+ "
            + (currentTimeDif - lastTimeDif)
            + "ms ("
            + percentFormat.format((double) readFileBytes
                / (double) totalFileBytes) + ")");
        lastTimeDif = currentTimeDif;
      }

      String[] lineSplit = line.split("\t");
      if ((lineSplit.length != 2) || lineSplit[0].isEmpty()
          || lineSplit[1].isEmpty()) {
        throw new ParseException(
            "The provided redirect map file has invalid content!", lineCount);
      }

      String articleName = lineSplit[0];
      String redirectName = lineSplit[1];

      // make sure to use the same string references for equal redirectNames to
      // reduce the amount of needed memory
      redirectName = tempRedirectNames.putIfAbsent(redirectName, redirectName);

      if (this.redirectMap.put(articleName, redirectName) != null) {
        throw new ParseException(
            "The provided redirect map file contains a duplicate entry for the "
                + "article '" + articleName + "'!", lineCount);
      }
    }

    reader.close();
  }

  /**
   * Checks if the given article is contained in the redirect map.
   * 
   * @param articleName
   *          The name of the article to check.
   * @return <code>true</code> if the article is contained, <code>false</code>
   *         otherwise.
   */
  public boolean containsArticle(String articleName) {
    return this.redirectMap.containsKey(articleName);
  }

  /**
   * Gets the article to which the given article redirects.
   * 
   * @param articleName
   *          The name of the article to get the redirect article.
   * @return The name of the article to which the given article redirects or
   *         <code>null</code> if the given article is not contained.
   */
  public String getRedirect(String articleName) {
    // TODO: remove the call to the 'used serializer' which is only needed to
    // create a smaller map for test purposes
    // RedirectMapUsedSerializer.getInstance().markArticleUsed(this,
    // articleName);

    return this.redirectMap.get(articleName);
  }
}
