package broccoli.entityrecognizer.data;

import java.util.HashSet;
import java.util.Set;
import broccoli.entityrecognizer.disambiguation.Context;

/**
 * An entity that can be recognized in text and is part of the broccoli 
 * ontology.
 * Similar to BroccoliEntity, but without storing informations about aliases.
 * 
 * @author Florian Bäurle, Elmar Haussmann, Manuel Ruder
 */
public class SimpleBroccoliEntity {

  /**
   * Persons have a gender.
   *
   */
  public enum Gender {
    /**
     * Male.
     */
    MALE, 
    /**
     * Female.
     */
    FEMALE
  };

  /**
   * The gender of the entity, if it is a person.
   */
  private Gender gender;

  /**
   * The entity name that identifies the entity in the broccoli ontology.
   */
  private String broccoliEntityName;
  
  /**
   * A set containing the classes the entity is an instance of.
   */
  private Set<String> classes;

  /**
   * The abstractness count of the entity.
   */
  private int abstractnessCount;
  
  /**
   * Name of the special class for female gender.
   */
  private static final String FEMALE_GENDER_CLASS = "gender_female";
  
  /**
   * Name of the special class for male gender.
   */
  private static final String MALE_GENDER_CLASS = "gender_male";

  /**
   * The context vector of this entity.
   */
  private Context context = new Context();
  
  /**
   * The score of the entity.
   */
  private int score;

  /**
   * Creates a new {@link SimpleBroccoliEntity}.
   * 
   * @param broccoliEntityString
   *          The Broccoli string representation of the entity.
   * @param classes
   *          A set containing the classes the entity is an instance of.
   */
  public SimpleBroccoliEntity(String broccoliEntityString,
      Set<String> classes) {
    this(broccoliEntityString, classes, 0, 0);
  }
  
  /**
   * Creates a new {@link SimpleBroccoliEntity}.
   * 
   * @param broccoliEntityString
   *          The Broccoli string representation of the entity.
   * @param classes
   *          A set containing the classes the entity is an instance of.
   */
  public SimpleBroccoliEntity(String broccoliEntityString, Set<String> classes,
      int score, int abstractnessCount) {
    this.score = score;
    this.abstractnessCount = abstractnessCount;
    this.broccoliEntityName = broccoliEntityString;
    this.classes = classes;
    // Set the gender.
    if (isInstanceOf(FEMALE_GENDER_CLASS)) {
      this.gender = Gender.FEMALE;
    } else if (isInstanceOf(MALE_GENDER_CLASS)) {
      this.gender = Gender.MALE;
    }
  }

  // /**
  // * Gets the name of the entity. (The substring after the last colon in the
  // * broccoli entity string.)
  // *
  // * @return The name of the entity.
  // */
  // public String getEntityName() {
  // int lastColonIndex = this.broccoliEntityString.lastIndexOf(':');
  // return this.broccoliEntityString.substring(lastColonIndex + 1);
  // }

  /**
   * Gets the Broccoli string representation of the entity.
   * 
   * @return The Broccoli string representation of the entity.
   */
  public String getBroccoliEntityName() {
    return this.broccoliEntityName;
  }

  /**
   * Gets a copy of the set which contains the classes the entity is an instance
   * of.
   * 
   * @return A copy of the set which contains the classes the entity is an
   *         instance of.
   */
  public Set<String> getClasses() {
    return new HashSet<String>(this.classes);
  }

  /**
   * Determines if this entity is an instance of the provided class.
   * 
   * @param classString
   *          The name of the class to check if the entity is an instance of.
   * @return <code>true</code> if the entity is an instance of the given class,
   *         <code>false</code> otherwise.
   */
  public boolean isInstanceOf(String classString) {
    return this.classes.contains(classString);
  }

  /**
   * Gets the abstractness count of the entity.
   * 
   * @return The abstractness count of the entity.
   */
  public int getAbstractnessCount() {
    return abstractnessCount;
  }

  /**
   * Sets the abstractness count of the entity.
   * 
   * @param abstractnessCount
   *          The abstractness count of the entity.
   */
  public void setAbstractnessCount(int abstractnessCount) {
    this.abstractnessCount = abstractnessCount;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof BroccoliEntity) {
      return this.broccoliEntityName.equals(((BroccoliEntity) obj)
          .getBroccoliEntityName());
    }
    return false;
  }

  @Override
  public int hashCode() {
    return this.broccoliEntityName.hashCode();
  }

  /**
   * 
   * @return
   */
  public int getScore() {
    return score;
  }

  /**
   * 
   * @param score
   */
  public void setScore(int score) {
    this.score = score;
  }
  
  /**
   * Get the gender - only valid values for a person.
   * @return
   */
  public Gender getGender() {
    return this.gender;
  }
  
  /**
   * Returns the semantic context of this entity.
   * @return
   */
  public Context getContext() {
    return this.context;
  }

  /**
   * Sets the semantic context of this entity.
   * @return
   */
  public void setContext(Context value) {
    this.context = value;
  }
  
}
