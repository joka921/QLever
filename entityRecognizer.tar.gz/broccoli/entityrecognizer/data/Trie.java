// Copyright 2014 Philipp Bausch<bauschp@informatik.uni-freiburg.de>

package broccoli.entityrecognizer.data;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;

/**
 * This is a simple implementation of a prefix tree. In broccoli it is used to
 * recogice entities in a fast an simple way.
 * 
 * @param <V>
 *          V is the Valu that will be stored in the leaves.
 * @author bauschp
 */
public class Trie<V> implements
    Map<String, V>,
    GeneralSurfaceMap.PrefixCheckable {
  /**
   * The parent node of this node. <b>null</b> if root of the whole tree.
   * 
   * @author bauschp
   */
  private Trie<V> parent;

  /**
   * The data field of a node.
   * 
   * @author bauschp
   */
  private V data;

  /**
   * The children of this node.
   * 
   * @author bauschp
   */
  private HashMap<Character, Trie<V>> children;
  /**
   * A main to benchmark put get and contains between this trie and a HashMap.
   */
  public static void main(String[] args) {
    int n = 1000000;

    long startTime = System.nanoTime();

    // BEGIN: benchmark for Java's built-in hashmap
    System.out.println("\n===== Java's built-in HashMap =====");
    int times = 20;
    long[] marks = new long[3];
    for (int round = 0; round < times; ++round) {
      Map<String, Integer> jMap = new HashMap<String, Integer>();
      runBenchmarks(n, marks, jMap);
    }
    printBenchmark(marks, times);

    // END
    // BEGIN: Trie
    System.out.println("\n===== Trie =====");
    marks = new long[3];
    for (int round = 0; round < times; ++round) {
      Map<String, Integer> jMap = new Trie<Integer>();
      runBenchmarks(n, marks, jMap);
    }
    printBenchmark(marks, times);
    // END
  }
  /**
   * Runs the benchmark on a Map Structure.
   */
  private static void runBenchmarks(int n, long[] marks,
      Map<String, Integer> jMap) {
    long startTime;
    startTime = System.nanoTime();
    for (int i = 0; i < n; i++) {
      jMap.put("" + i, i);
    }
    marks[0] += getTimeDelta(startTime);

    startTime = System.nanoTime();
    for (int i = 0; i < n; i++) {
      jMap.get("" + i);
    }
    marks[1] += getTimeDelta(startTime);

    startTime = System.nanoTime();
    for (int i = 0; i < n; i++) {
      jMap.containsKey("" + i);
    }
    marks[2] += getTimeDelta(startTime);
  }
  /**
   * Returns the Delta between now and a given startTime.
   */
  private static long getTimeDelta(long startTime) {
    return System.nanoTime() - startTime;
  }
  /**
   * Prints the benchmark results to the std out.
   */
  private static void printBenchmark(long[] times, float count) {
    System.out.println("\n-- puts(key, value) --");
    System.out.println("Time(s):" + times[0] / count / 1000000000.0);
    System.out.println("\n-- gets(key) --");
    System.out.println("Time(s):" + times[1] / count / 1000000000.0);
    System.out.println("\n-- containsKey(key) --");
    System.out.println("Time(s):" + times[2] / count / 1000000000.0);

  }

  @Override
  public void clear() {
    data = null;
    parent = null;
    children = null;
  }

  @Override
  public boolean isPrefix(String prefix) {
    Trie<V> prefixNode = traverseTree(prefix, false);
    return prefixNode != null && prefixNode.children != null;
  }

  @Override
  public boolean containsKey(Object key) {
    return get(key) != null;
  }
  /**
   * Returns the Node for given Key.
   */
  private Trie<V> traverseTree(String key, boolean allowNew) {
    Trie<V> currentNode = this;
    for (int i = 0; i < key.length(); ++i) {
      if (currentNode.children == null) {
        if (allowNew) {
          currentNode.children = new HashMap<Character, Trie<V>>();
        } else {
          return null;
        }
      }
      if (!currentNode.children.containsKey(key.charAt(i))) {
        if (allowNew) {
          Trie<V> child = new Trie<V>();
          child.parent = currentNode;
          currentNode.children.put(key.charAt(i), child);
        } else {
          return null;
        }
      }
      currentNode = currentNode.children.get(key.charAt(i));
    }
    return currentNode;
  }

  @Override
  public boolean containsValue(Object value) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public Set<java.util.Map.Entry<String, V>> entrySet() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public V get(Object key) {
    if (!(key instanceof String)) {
      return null;
    }
    Trie<V> leaf = traverseTree((String) key, false);
    return leaf == null ? null : leaf.data;
  }

  @Override
  public boolean isEmpty() {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public Set<String> keySet() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public V put(String key, V value) {
    Trie<V> leaf = traverseTree(key, true);
    V tmp = leaf.data;
    leaf.data = value;
    return tmp;
  }

  @Override
  public void putAll(Map<? extends String, ? extends V> m) {
    // TODO Auto-generated method stub

  }

  @Override
  public V remove(Object key) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public Collection<V> values() {
    // TODO Auto-generated method stub
    return null;
  }
}
