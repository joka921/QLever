// Copyright 2014, University of Freiburg,
// Chair of Algorithms and Data Structures.
// Author: Manuel Ruder <rudera>
package broccoli.entityrecognizer.disambiguation;

import java.util.List;

import broccoli.uima.typesystem.Token;
import broccoli.uima.typesystem.Sentence;

import gnu.trove.map.hash.TObjectFloatHashMap;
import gnu.trove.iterator.TObjectFloatIterator;

/**
 * A class representing a context vector in sparse form.
 */
public class Context {

  /**
   * Sparse representation of feature space.
   * ( Maps a feature (typically a word) to its score value (typically tf-idf) )
   */
  private TObjectFloatHashMap<String> features = null;

  /**
   * Add a new feature to this context vector.
   * Existing values will be overwritten.
   */
  public void addFeature(String feature, float score) {
    if (features == null) {
      features = new TObjectFloatHashMap<String>();
    }
    features.put(feature, score);
  }

  /**
   * Add a new feature to this context vector.
   * Or if the feature already exists, add the score to the existing score.
   */
  public void adjustOrAddFeature(String feature, float score) {
    if (features == null) {
      features = new TObjectFloatHashMap<String>();
    }
    features.adjustOrPutValue(feature, score, score);
  }

  /**
   * Compute length (Euclidean distance) of the context vector.
   */
  private float computeLength() {
    float result = 0.0f;
    if (features == null) {
      return result;
    }
    for (TObjectFloatIterator<String> it = features.iterator(); it.hasNext();) {
      it.advance();
      result += it.value() * it.value();
    }
    return (float) Math.sqrt(result);
  }

  /**
   * Compute the average score of all features.
   */
  public float computeAverage() {
    float result = 0.0f;
    if (features == null) {
      return result;
    }
    for (TObjectFloatIterator<String> it = features.iterator(); it.hasNext();) {
      it.advance();
      result += it.value();
    }
    return result / features.size();
  }

  /**
   * Normalize this context vector.
   */
  public void normalize() {
    if (features == null) {
      return;
    }
    float length = computeLength();
    for (TObjectFloatIterator<String> it = features.iterator();
        it.hasNext();) {
      it.advance();
      it.setValue(it.value() / length);
    }
  }

  /**
   * Set up the feature space vector to a given capacity.
   */
  public void setUp(int newCapacity) {
    if (features == null) {
      features = new TObjectFloatHashMap<String>(newCapacity);
    } else {
      features.setUp(newCapacity);
    }
  }

  /**
   * Computes similarity to the given other context.
   * If both contexts are normalized, 0 indicates no similarity
   * and 1 indicates full similarity.
   */
  public float similarityTo(Context other) {
    if (this.features == null || other.features == null) {
      return 0.0f;
    }
    TObjectFloatHashMap<String> larger =
        other.features.size() > this.features.size()
        ? other.features : this.features;
    TObjectFloatHashMap<String> smaller =
        other.features.size() > this.features.size()
        ? this.features : other.features;
    float score = 0.0f;
    for (TObjectFloatIterator<String> it = smaller.iterator(); it.hasNext();) {
      it.advance();
      if (larger.containsKey(it.key())) {
        score += it.value() * larger.get(it.key());
      }
    }
    return score;
  }

  /**
   * Add all valid tokens from the given sentence to this context.
   * The score will be calculated as token frequency times weight.
   */
  public void addSentence(Sentence sentence, float weight) {
    for (int i = 0; i < sentence.getTokens().size(); i++) {
      Token tok = (Token) sentence.getTokens().get(i);
      if (!isValidToken(tok)) {
        continue;
      }
      adjustOrAddFeature(tok.getCoveredText(), weight);
    }
  }

  /**
   * Subtract all valid tokens from the given sentence from this context.
   * The "score" will be calculated as token frequency times weight.
   * Removes features that have a sore less than the given threshold.
   */
  public void subtractSentence(Sentence sentence, float weight,
      float removeThreshold) {
    if (features == null) {
      return;
    }
    for (int i = 0; i < sentence.getTokens().size(); i++) {
      Token tok = (Token) sentence.getTokens().get(i);
      if (!isValidToken(tok)) {
        continue;
      }
      float newValue = features.adjustOrPutValue(tok.getCoveredText(),
          -1 * weight, -1 * weight);
      if (newValue < removeThreshold) {
        features.remove(tok.getCoveredText());
      }
    }
  }

  /**
   * Returns a new context for a given sentence.
   */
  public static Context ofSentence(Sentence sentence) {
    Context context = new Context();
    context.setUp(sentence.getTokens().size());
    context.addSentence(sentence, 1.0f);
    return context;
  }

  /**
   * Returns a new context for a given sentences.
   */
  public static Context ofSentences(List<Sentence> sentences) {
    Context context = new Context();
    for (int i = sentences.size() - 1; i >= 0; --i) {
      context.addSentence(sentences.get(i), 1.0f);
    }
    return context;
  }

  /**
   * Valid tokens are nouns, adjectives or verbs.
   */
  private static boolean isValidToken(Token token) {
    if (token.getCoveredText().length() == 0) {
      return false;
    }
    if (token.getPosTag() == null) {
      // fallback to ensure that this recognizer works, even if there
      // are no pos-tags.
      return token.getCoveredText().length() > 3;
    }
    // If the token is a noun, verb, adverb or adjective
    if (token.getPosTag().startsWith("N") || token.getPosTag().startsWith("J")
        || token.getPosTag().startsWith("V")
        || token.getPosTag().startsWith("R")) {
      return true;
    }
    return false;
  }

}