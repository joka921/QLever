package broccoli.utility;

import java.util.regex.Pattern;

/**
 * Utility class to normalize entity names.
 * 
 * @author Florian Bäurle
 */
public class EntityNameNormalizer {
  /**
   * The regex pattern that is used to normalize the entity names.
   */
  private static Pattern normalizePattern = Pattern.compile(" ");
  
  /**
   * The entity prefix that is used internally in the index.
   */
  private static final String ENTITY_PREFIX = ":e:";

  /**
   * Normalizes the given entity name for consistent usage.
   * 
   * @param entityName
   *          The entity name to normalize.
   * @return The normalized entity name.
   */
  public static String normalize(String entityName) {
    if (entityName == null) {
      return null;
    }
    if (entityName.isEmpty()) {
      return entityName;
    }

    // replace spaces by underscores
    String temp = normalizePattern.matcher(entityName).replaceAll("_");
    // make the first letter uppercase
    // Aug23-2013(Elmar): No lpnger force first character uppercase
    // temp = temp.substring(0, 1).toUpperCase() + temp.substring(1);

    return new String(temp);
  }
  
  
  /**
   * Normalizes the entity name (remove whitespace etc. by underscore) and
   * prefixes with the entity-prefix.
   * @param entityName
   * @return
   */
  public static String toNormalizedBroccoliEntity(String entityName) {
    return ENTITY_PREFIX + EntityNameNormalizer.normalize(entityName);
  }
  
  /**
   * Only prefixes the string with the entity-prefix.
   * @param entityName
   * @return
   */
  public static String prefixBroccoliEntity(String entityName) {
    return ENTITY_PREFIX + entityName;
  }
}
