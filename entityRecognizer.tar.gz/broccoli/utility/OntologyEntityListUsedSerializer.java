package broccoli.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import broccoli.entityrecognizer.data.OntologyEntityList;

/**
 * Test class.
 * 
 * @author Florian Bäurle
 */
public class OntologyEntityListUsedSerializer {
  /**
   * Test class.
   */
  private static final String OUTPUT_FILE_PATH =
      "/home/baeurlef/ontology-test.entity-list";

  /**
   * Test class.
   */
  private static OntologyEntityListUsedSerializer instance;

  /**
   * Test class.
   */
  private File outputFile;

  /**
   * Test class.
   */
  private Set<String> usedEntityNames = new HashSet<String>();

  /**
   * Test class.
   */
  private OntologyEntityListUsedSerializer() {
    this.outputFile = new File(OUTPUT_FILE_PATH);
    if (this.outputFile.exists()) {
      if (!this.outputFile.delete()) {
        throw new IllegalStateException(
            "The output file for the serialization of the used ontology entity "
                + "list already exists and could not be deleted!");
      }
    }
  }

  /**
   * Test class.
   */
  public static OntologyEntityListUsedSerializer getInstance() {
    if (instance == null) {
      instance = new OntologyEntityListUsedSerializer();
    }
    return instance;
  }

  /**
   * Test class.
   */
  public void markEntityUsed(OntologyEntityList ontologyEntityList,
    String entityName) {
    if (!this.usedEntityNames.contains(entityName)) {
      if (ontologyEntityList.containsEntity(entityName)) {
        this.usedEntityNames.add(entityName);
        this.serializeUsedEntry(ontologyEntityList, entityName);
      }
    }
  }

  /**
   * Test class.
   */
  private void serializeUsedEntry(OntologyEntityList ontologyEntityList,
    String entityName) {
    try {
      FileOutputStream stream = new FileOutputStream(this.outputFile, true);
      OutputStreamWriter streamWriter =
          new OutputStreamWriter(stream, "UTF-8");
      BufferedWriter writer = new BufferedWriter(streamWriter);

      StringBuilder classesString = new StringBuilder();
      Set<String> classes = ontologyEntityList.getEntityClasses(entityName);
      Iterator<String> classesIt = classes.iterator();
      while (classesIt.hasNext()) {
        String currentClass = classesIt.next();
        if (classesString.length() > 0) {
          classesString.append(",");
        }
        classesString.append(currentClass);
      }

      writer.write(ontologyEntityList.getBroccoliString(entityName) + "\t"
          + classesString.toString() + "\n");

      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  // private void serializeUsedEntries() {
  // try {
  // File outputFile = new File(OUTPUT_FILE);
  // FileOutputStream stream = new FileOutputStream(outputFile);
  // OutputStreamWriter streamWriter = new OutputStreamWriter(stream, "UTF-8");
  // BufferedWriter writer = new BufferedWriter(streamWriter);
  //
  // Iterator<String> it = this.usedEntityNames.iterator();
  // while (it.hasNext()) {
  // String currentEntityName = it.next();
  //
  // StringBuilder classesString = new StringBuilder();
  // Set<String> classes = this.entityNamesClassesMap.get(currentEntityName);
  // Iterator<String> it1 = classes.iterator();
  // while (it1.hasNext()) {
  // String currentClass = it1.next();
  // if (classesString.length() > 0) {
  // classesString.append(",");
  // }
  // classesString.append(currentClass);
  // }
  //
  // writer.write(this.getBroccoliString(currentEntityName) + "\t"
  // + classesString.toString() + "\n");
  // }
  //
  // writer.close();
  // } catch (IOException e) {
  // e.printStackTrace();
  // }
  // }
}
