package broccoli.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.util.Set;

import broccoli.entityrecognizer.data.RedirectMap;

/**
 * Test class.
 * 
 * @author Florian Bäurle
 */
public class RedirectMapUsedSerializer {
  /**
   * Test class.
   */
  private static final String OUTPUT_FILE_PATH =
      "/home/baeurlef/semantic-wikipedia-test.redirect-map";

  /**
   * Test class.
   */
  private static RedirectMapUsedSerializer instance;

  /**
   * Test class.
   */
  private File outputFile;

  /**
   * Test class.
   */
  private Set<String> usedArticleNames = new HashSet<String>();

  /**
   * Test class.
   */
  private RedirectMapUsedSerializer() {
    this.outputFile = new File(OUTPUT_FILE_PATH);
    if (this.outputFile.exists()) {
      if (!this.outputFile.delete()) {
        throw new IllegalStateException(
            "The output file for the serialization of the used redirect map "
                + "already exists and could not be deleted!");
      }
    }
  }

  /**
   * Test class.
   */
  public static RedirectMapUsedSerializer getInstance() {
    if (instance == null) {
      instance = new RedirectMapUsedSerializer();
    }
    return instance;
  }

  /**
   * Test class.
   */
  public void markArticleUsed(RedirectMap redirectMap, String articleName) {
    if (!this.usedArticleNames.contains(articleName)) {
      if (redirectMap.containsArticle(articleName)) {
        this.usedArticleNames.add(articleName);
        this.serializeUsedEntry(redirectMap, articleName);
      }
    }
  }

  /**
   * Test class.
   */
  private void serializeUsedEntry(RedirectMap redirectMap, String articleName) {
    try {
      FileOutputStream stream = new FileOutputStream(this.outputFile, true);
      OutputStreamWriter streamWriter =
          new OutputStreamWriter(stream, "UTF-8");
      BufferedWriter writer = new BufferedWriter(streamWriter);

      writer.write(articleName + "\t" + redirectMap.getRedirect(articleName)
          + "\n");

      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  // private void serializeUsedEntries() {
  // try {
  // File outputFile =
  // new File("/home/baeurlef/semantic-wikipedia-test.redirect-map");
  // FileOutputStream stream = new FileOutputStream(outputFile);
  // OutputStreamWriter streamWriter = new OutputStreamWriter(stream, "UTF-8");
  // BufferedWriter writer = new BufferedWriter(streamWriter);
  //
  // Iterator<String> it = this.usedArticleNames.iterator();
  // while (it.hasNext()) {
  // String currentArticleName = it.next();
  // writer.write(currentArticleName + "\t"
  // + this.redirectMap.get(currentArticleName) + "\n");
  // }
  //
  // writer.close();
  // } catch (IOException e) {
  // e.printStackTrace();
  // }
  // }
}
