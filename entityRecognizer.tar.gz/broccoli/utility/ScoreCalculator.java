package broccoli.utility;

import broccoli.entityrecognizer.data.BroccoliEntity;

/**
 * Calculates the entity scores for a document.
 * 
 * @author Florian Bäurle
 */
public class ScoreCalculator {

  /**
   * The broccoli string of the entity of the document.
   */
  private String documentEntityBroccoliString;

  /**
   * Creates a new {@link ScoreCalculator} for a document.
   * 
   * @param documentEntityBroccoliString
   *          The broccoli string of the entity of the document or
   *          <code>null</code> if the document does not represent an entity.
   */
  public ScoreCalculator(String documentEntityBroccoliString) {
    this.documentEntityBroccoliString = documentEntityBroccoliString;
  }

  /**
   * Calculates the score of the given entity for the configured document.
   * 
   * @param entityInfo
   *          The broccoli entity info object of the entity of which to
   *          calculate the score.
   * @param sectionIndex
   *          The section index in which the entity occurs in the document.
   *          (Starting from 0)
   * @param sentenceIndex
   *          The sentence index in which the entity occurs in the given section
   *          of the document. (Starting form 0)
   * @return The score of the given entity.
   */
  public int calculateScore(BroccoliEntity entityInfo, int sectionIndex,
    int sentenceIndex) {

    // give abstract entities (measured using the abstractness count) a score of
    // 0
    if (entityInfo.getAbstractnessCount() >= 10) {
      return 0;
    } else {
      // if we process the document of the entity, give it a higher score
      if (entityInfo.getBroccoliEntityName().equals(
          documentEntityBroccoliString)) {
        // if we are in the first section of the document, give it a higher
        // score
        if (sectionIndex == 0) {
          // if we are in the first sentence, give it a higher score
          if (sentenceIndex == 0) {
            return 150;
          }
          return 120;
        }
        return 100;
      }
      return 2;
    }
  }
}
